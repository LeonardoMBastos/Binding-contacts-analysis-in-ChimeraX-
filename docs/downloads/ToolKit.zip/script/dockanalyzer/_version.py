"""Version information for DockAnalyzer."""

from __future__ import annotations

__version__ = "0.1.2"

__all__ = ["__version__"]
