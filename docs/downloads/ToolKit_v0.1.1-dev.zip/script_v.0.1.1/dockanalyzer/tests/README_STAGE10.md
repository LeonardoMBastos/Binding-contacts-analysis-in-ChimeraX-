# Stage 10 tests

`test_stage10_parallel_multipose.py` protects the detached-worker multipose
parallelization introduced in Stage 10. These tests are cumulative with the
Stage 1–9 regression suite and do not hardcode Stage 10 behavior into the
scientific detectors.
