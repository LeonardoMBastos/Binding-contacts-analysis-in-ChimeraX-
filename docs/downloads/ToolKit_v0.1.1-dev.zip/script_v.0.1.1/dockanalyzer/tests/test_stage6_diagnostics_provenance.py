"""Stage 6 regression tests for diagnostics and provenance collection."""

from __future__ import annotations

import unittest
from types import SimpleNamespace
from unittest.mock import patch

from dockanalyzer import analyze


class Stage6DiagnosticsProvenanceTests(unittest.TestCase):
    def test_all_internal_modules_are_reported_available(self):
        versions = analyze.collect_observability_module_versions()
        unavailable = [
            name
            for name in analyze.OBSERVABILITY_INTERNAL_MODULES
            if not versions.get(name, {}).get("available", False)
        ]
        self.assertEqual(unavailable, [])

    def test_config_argument_does_not_shadow_config_module(self):
        config = analyze.AnalysisObservabilityConfig(include_module_versions=True)
        versions = analyze.collect_observability_module_versions(config=config)
        entry = versions["config"]
        self.assertTrue(entry["available"])
        self.assertEqual(entry["module"], "dockanalyzer.config")
        self.assertTrue(str(entry.get("file") or "").endswith("config.py"))

    def test_internal_module_entries_include_real_module_identity(self):
        versions = analyze.collect_observability_module_versions()
        for name in analyze.OBSERVABILITY_INTERNAL_MODULES:
            entry = versions[name]
            self.assertTrue(entry["available"], name)
            self.assertEqual(entry["module"].split(".")[-1], name)
            self.assertTrue(entry.get("version"), name)
            self.assertTrue(entry.get("file"), name)

    def test_unexpected_internal_load_failure_is_not_silently_hidden(self):
        original_get = analyze.get_loaded_analysis_module
        original_load = analyze.load_analysis_module

        def fake_get(name, *, package=None):
            if name == "geometry":
                return None
            return original_get(name, package=package)

        def fake_load(name, *, package=None, required=True, reload=False):
            if name == "geometry":
                raise RuntimeError("synthetic module load failure")
            return original_load(
                name,
                package=package,
                required=required,
                reload=reload,
            )

        with patch.object(analyze, "get_loaded_analysis_module", side_effect=fake_get), \
             patch.object(analyze, "load_analysis_module", side_effect=fake_load):
            versions = analyze.collect_observability_module_versions()
            compact = analyze._compact_module_versions(
                SimpleNamespace(
                    session_info=SimpleNamespace(available=False, chimerax_version=None)
                )
            )

        entry = versions["geometry"]
        self.assertFalse(entry["available"])
        self.assertIsNone(entry["version"])
        self.assertEqual(entry["load_error"]["type"], "RuntimeError")
        self.assertIn("synthetic module load failure", entry["load_error"]["message"])
        self.assertEqual(compact["geometry"]["load_error"]["type"], "RuntimeError")
        self.assertIn(
            "synthetic module load failure",
            compact["geometry"]["load_error"]["message"],
        )

    def test_provenance_snapshot_contains_correct_internal_availability(self):
        provenance = analyze.collect_analysis_provenance(
            config=analyze.AnalysisObservabilityConfig(
                include_platform=False,
                include_python=False,
                include_process=False,
                include_chimerax=False,
                include_environment=False,
                include_input_fingerprints=False,
                include_module_versions=True,
            )
        )
        versions = provenance.to_dict()["module_versions"]
        for name in analyze.OBSERVABILITY_INTERNAL_MODULES:
            self.assertTrue(versions[name]["available"], name)

    def test_compact_run_versions_preserve_correct_internal_status(self):
        result = SimpleNamespace(
            session_info=SimpleNamespace(available=False, chimerax_version=None)
        )
        versions = analyze._compact_module_versions(result)
        for name in analyze.OBSERVABILITY_INTERNAL_MODULES:
            self.assertTrue(versions[name]["available"], name)
            self.assertTrue(versions[name]["version"], name)
        self.assertIn("dockanalyzer", versions)
        self.assertIn("python", versions)


if __name__ == "__main__":
    unittest.main()
