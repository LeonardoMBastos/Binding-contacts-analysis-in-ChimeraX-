"""DockAnalyzer external regression tests."""
