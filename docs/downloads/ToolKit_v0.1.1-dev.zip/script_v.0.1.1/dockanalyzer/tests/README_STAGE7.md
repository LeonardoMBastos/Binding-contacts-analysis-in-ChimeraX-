# Stage 7 regression tests

Stage 7 validates ChimeraX visualization command rendering and runtime diagnostics.

It verifies that:

- orthographic camera mode is emitted as `camera ortho`;
- compound atom specifications are emitted as a single ChimeraX command token;
- an unresolved framing selection never emits `view none`;
- failed non-optional ChimeraX commands produce a partial visualization result;
- optional failed commands remain visible as warnings;
- command failures become recoverable stage diagnostics;
- stage diagnostics reach the compact ChimeraX run summary diagnostics.
