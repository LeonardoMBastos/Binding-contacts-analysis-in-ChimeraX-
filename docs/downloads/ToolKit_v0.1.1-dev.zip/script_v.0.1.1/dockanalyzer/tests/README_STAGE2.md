# Stage 2 tests

`test_stage2_export_safety.py` verifies that standard DockAnalyzer exports do not serialize cached stage-result payloads or duplicated hydrogen-bond runtime containers stored in DockModel metadata.

The tests use deliberately large sentinel payloads and confirm that:

- the sentinels never appear in serialized output;
- cache entries contain summaries rather than `value`;
- useful public metadata is retained;
- JSON and CSV multipose exports remain bounded;
- serialized size is independent of cache payload size.

These tests do not change or inject values into production analysis.
