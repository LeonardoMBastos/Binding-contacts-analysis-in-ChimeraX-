"""Self-tests for the Stage 1 DockAnalyzer regression baseline."""

from __future__ import annotations

import json
import unittest
from pathlib import Path

from tests.stage1_reference import (
    DEFAULT_BASELINE_PATH,
    validate_generic_run_summary,
    validate_paths,
    validate_scientific_baseline,
)


FIXTURES = Path(__file__).resolve().parent / "fixtures"
REFERENCE_SUMMARY = FIXTURES / "reference_run_20260807_144231_run_summary.json"


class Stage1ReferenceTests(unittest.TestCase):
    def _load(self, path: Path):
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)

    def test_reference_summary_satisfies_generic_invariants(self):
        report = validate_generic_run_summary(self._load(REFERENCE_SUMMARY))
        self.assertEqual(report.errors, ())

    def test_reference_summary_matches_scientific_baseline(self):
        report = validate_paths(REFERENCE_SUMMARY, DEFAULT_BASELINE_PATH)
        self.assertTrue(report.succeeded, report.errors)
        self.assertEqual(report.errors, ())

    def test_changed_interaction_count_is_detected(self):
        summary = self._load(REFERENCE_SUMMARY)
        baseline = self._load(DEFAULT_BASELINE_PATH)
        summary["scores"][0]["interaction_count"] += 1
        report = validate_scientific_baseline(summary, baseline)
        self.assertFalse(report.succeeded)
        self.assertTrue(
            any("interaction_count changed" in error for error in report.errors)
        )

    def test_changed_score_is_detected(self):
        summary = self._load(REFERENCE_SUMMARY)
        baseline = self._load(DEFAULT_BASELINE_PATH)
        summary["scores"][0]["score"] += 0.1
        report = validate_scientific_baseline(summary, baseline)
        self.assertFalse(report.succeeded)
        self.assertTrue(any("score changed" in error for error in report.errors))

    def test_changed_ranking_is_detected(self):
        summary = self._load(REFERENCE_SUMMARY)
        baseline = self._load(DEFAULT_BASELINE_PATH)
        summary["ranking"]["entries"][0]["rank"] = 2
        summary["ranking"]["entries"][1]["rank"] = 1
        summary["ranking"]["best_pose_id"] = "4"
        report = validate_scientific_baseline(summary, baseline)
        self.assertFalse(report.succeeded)
        self.assertTrue(any("Best pose changed" in error for error in report.errors))

    def test_missing_pose_is_detected_generically(self):
        summary = self._load(REFERENCE_SUMMARY)
        summary["scores"] = summary["scores"][:-1]
        report = validate_generic_run_summary(summary)
        self.assertFalse(report.succeeded)
        self.assertTrue(any("score pose IDs" in error for error in report.errors))


if __name__ == "__main__":
    unittest.main()
