# Stage 4 tests

`test_stage4_multipose_report.py` protects multipose report normalization. It verifies that aggregate analysis wrappers do not become synthetic interactions or poses and that reports aggregate real interaction containers from the underlying DockModels.
