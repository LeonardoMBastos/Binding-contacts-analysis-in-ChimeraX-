"""Stage 5 regression tests for complete export and runtime timing."""

from __future__ import annotations

import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from dockanalyzer import analyze, export
from dockanalyzer.analyze import (
    AnalysisStageResult,
    AnalysisStatus,
    ExportIntegrationConfig,
    ExportStageTarget,
    ExportTargetKind,
    adapt_native_export_result,
    run_export_analysis,
)
from dockanalyzer.export import ExportOptions, MultiposeExportOptions, export_multiple_poses
from tests.test_stage2_export_safety import make_pose


class Stage5ExportTimingTests(unittest.TestCase):
    def _native_options(self, directory: Path, *, manifest: bool = False) -> MultiposeExportOptions:
        return MultiposeExportOptions(
            export=ExportOptions(
                output_dir=directory,
                basename="stage5_test",
                formats=("json", "csv"),
                include_manifest=manifest,
                include_provenance=manifest,
                update_model_files=False,
                hash_algorithm="sha256" if manifest else None,
            )
        )

    def test_native_export_reports_preparation_serialization_and_write_timings(self):
        with tempfile.TemporaryDirectory() as directory:
            result = export_multiple_poses(
                [make_pose(), make_pose(), make_pose()],
                options=self._native_options(Path(directory)),
                basename="stage5_test",
            )
        timings = result.metadata.get("export_timings", {})
        for key in (
            "normalize_poses_seconds",
            "build_pose_records_seconds",
            "build_tables_seconds",
            "prepare_total_seconds",
            "serialize_json_seconds",
            "write_json_seconds",
            "write_csv_seconds",
            "total_seconds",
        ):
            self.assertIn(key, timings)
            self.assertGreaterEqual(timings[key], 0.0)
        self.assertGreaterEqual(result.duration_seconds or 0.0, timings["prepare_total_seconds"])

    def test_preparation_time_is_included_in_export_result_duration(self):
        original = export._normalize_multipose_pose_items

        def delayed(values):
            time.sleep(0.03)
            return original(values)

        with tempfile.TemporaryDirectory() as directory, patch.object(
            export, "_normalize_multipose_pose_items", side_effect=delayed
        ):
            result = export_multiple_poses(
                [make_pose()],
                options=self._native_options(Path(directory)),
                basename="stage5_delay",
            )
        timings = result.metadata["export_timings"]
        self.assertGreaterEqual(timings["normalize_poses_seconds"], 0.02)
        self.assertGreaterEqual(result.duration_seconds or 0.0, 0.02)

    def test_manifest_hash_and_manifest_write_are_timed_separately(self):
        with tempfile.TemporaryDirectory() as directory:
            result = export_multiple_poses(
                [make_pose()],
                options=self._native_options(Path(directory), manifest=True),
                basename="stage5_manifest",
            )
        timings = result.metadata["export_timings"]
        self.assertIn("collect_provenance_seconds", timings)
        self.assertIn("calculate_hashes_seconds", timings)
        self.assertIn("build_manifest_seconds", timings)
        self.assertIn("write_manifest_seconds", timings)
        self.assertIsNotNone(result.manifest)

    def test_analyze_adapter_preserves_native_export_timings(self):
        with tempfile.TemporaryDirectory() as directory:
            native = export_multiple_poses(
                [make_pose()],
                options=self._native_options(Path(directory)),
                basename="stage5_adapter",
            )
            target = ExportStageTarget(
                source=make_pose(),
                kind=ExportTargetKind.MULTIPOSE,
                items=(make_pose(),),
                name="stage5_adapter",
            )
            config = ExportIntegrationConfig(
                output_directory=Path(directory),
                formats=("json",),
                validate_before_export=False,
                validate_after_export=False,
                attach_result=False,
                update_dock_model_files=False,
            )
            adapted = adapt_native_export_result(native, target=target, config=config)
        self.assertIn("export_timings", adapted.metadata)
        self.assertIn("prepare_total_seconds", adapted.metadata["export_timings"])
        self.assertEqual(
            adapted.metadata["native_export_duration_seconds"],
            native.duration_seconds,
        )

    def test_integration_export_duration_covers_complete_integration_path(self):
        with tempfile.TemporaryDirectory() as directory:
            config = ExportIntegrationConfig(
                output_directory=Path(directory),
                basename="stage5_integration",
                formats=("json",),
                include_manifest=False,
                include_provenance=False,
                hash_algorithm=None,
                update_dock_model_files=False,
                attach_result=False,
                reuse_result=False,
                validate_before_export=False,
                validate_after_export=False,
            )
            output = run_export_analysis(
                multipose_result=[make_pose(), make_pose()],
                config=config,
                export_module=export,
            )
        timings = output.metadata.get("integration_timings", {})
        self.assertIn("resolve_target_seconds", timings)
        self.assertIn("native_export_seconds", timings)
        self.assertIn("adapt_result_seconds", timings)
        self.assertIn("attach_results_seconds", timings)
        self.assertIn("total_seconds", timings)
        self.assertAlmostEqual(output.duration_seconds or 0.0, timings["total_seconds"], places=6)
        self.assertLessEqual(output.started_at, output.finished_at)
        stage_result = analyze.export_stage_output_to_result(output)
        compact = analyze._compact_stage_statuses({"export": stage_result})
        self.assertIn("export_timings", compact["export"])
        self.assertIn("integration_timings", compact["export"])

    def test_chimerax_output_started_at_is_captured_before_dispatch(self):
        options = SimpleNamespace(
            strict=False,
            mode="multipose",
            include_unknown_poses=True,
        )
        selection = SimpleNamespace(
            mode="multipose",
            pose_count=1,
            warnings=[],
        )
        request = SimpleNamespace(request_id="stage5-request")
        analysis_output = SimpleNamespace(
            status=AnalysisStatus.SUCCEEDED,
            succeeded=True,
        )
        session_info = SimpleNamespace()
        timestamps = iter(("2026-08-07T17:42:31+00:00", "2026-08-07T17:42:32+00:00"))
        with patch.object(analyze, "_utc_timestamp", side_effect=lambda: next(timestamps)), \
             patch.object(analyze, "coerce_chimerax_command_options", return_value=options), \
             patch.object(analyze, "resolve_chimerax_session", return_value=None), \
             patch.object(analyze, "resolve_chimerax_model_selection", return_value=selection), \
             patch.object(analyze, "build_chimerax_analysis_request", return_value=request), \
             patch.object(analyze, "emit_chimerax_message", return_value=None), \
             patch.object(analyze, "dispatch_chimerax_analysis", return_value=analysis_output), \
             patch.object(analyze, "inspect_chimerax_session", return_value=session_info), \
             patch.object(analyze, "_run_chimerax_post_actions", return_value=None):
            result = analyze.analyze_chimerax_session()
        self.assertEqual(result.started_at, "2026-08-07T17:42:31+00:00")
        self.assertEqual(result.finished_at, "2026-08-07T17:42:32+00:00")
        self.assertGreaterEqual(result.duration_seconds or 0.0, 0.0)


if __name__ == "__main__":
    unittest.main()
