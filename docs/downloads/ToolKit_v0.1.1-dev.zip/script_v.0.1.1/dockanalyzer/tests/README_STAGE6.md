# Stage 6 tests

Stage 6 validates DockAnalyzer diagnostics and provenance collection.

The tests ensure that:

- all internal DockAnalyzer modules are reported as available when importable;
- the observability `config` argument cannot shadow `dockanalyzer.config`;
- internal module provenance contains module identity, source path and version;
- unexpected module-load failures are recorded explicitly instead of silently becoming generic `available: false` entries;
- provenance snapshots preserve corrected module availability;
- compact ChimeraX run summaries preserve the same corrected availability.

These tests do not alter or exercise molecular interaction criteria.
