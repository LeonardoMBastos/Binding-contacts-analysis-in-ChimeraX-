# Stage 1 — Scientific Regression Baseline

This directory is test-only infrastructure. No baseline value is imported by
or injected into the production `dockanalyzer` package.

The frozen reference run is the successful 2026-08-07 multipose analysis with
three poses. It protects only the scientific outputs that were already known to
be valid before output/performance fixes begin:

- pose 2: 141 interactions, score 14.766099999999975, rank 1;
- pose 3: 107 interactions, score 8.306399999999993, rank 3;
- pose 4: 162 interactions, score 12.910799999999973, rank 2;
- all three poses succeeded, are score-comparable, and have no failed stages.

Known export, report, visualization, observability, and timing defects are
listed in the baseline metadata but are intentionally not accepted as desired
behavior.

## Run the Stage 1 self-tests

From the `script` directory:

```bash
python -m unittest discover -s tests -p "test_*.py"
```

## Compare a future run against the scientific baseline

From the `script` directory:

```bash
python -m tests.stage1_reference PATH_TO_NEW_run_summary.json
```

The validator also checks generic multipose invariants such as consistency
between input pose IDs, score records, ranking entries, and per-pose stage
records. These generic checks do not assume that future DockAnalyzer analyses
must contain three poses or reproduce the reference scores.
