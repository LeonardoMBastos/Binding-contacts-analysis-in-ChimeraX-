# Stage 5 regression tests

Stage 5 instruments the export/runtime pipeline without changing molecular detection or scoring.

`test_stage5_export_timing.py` verifies that:

- multipose preparation is included in the native export duration;
- pose normalization, record/table construction, JSON serialization and file writing are timed separately;
- provenance, file hashes, manifest construction and manifest writing are timed separately;
- native export timings survive the `analyze.py` integration adapter;
- integration timing covers target resolution, validation/native export, adaptation and attachment;
- the ChimeraX run-level `started_at` timestamp is captured before analysis dispatch.
