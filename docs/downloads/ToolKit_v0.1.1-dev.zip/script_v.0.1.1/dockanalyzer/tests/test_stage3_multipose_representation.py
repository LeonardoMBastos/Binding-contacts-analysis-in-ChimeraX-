"""Stage 3 regression tests for multipose target normalization."""

from __future__ import annotations

import csv
import json
import tempfile
import unittest
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from dockanalyzer.analyze import (
    AnalysisStatus,
    MultiPoseAnalysisResult,
    PoseAnalysisResult,
    _export_collect_dock_models,
    resolve_export_stage_target,
)
from dockanalyzer.export import (
    ExportOptions,
    MultiposeExportOptions,
    export_multiple_poses,
    prepare_multipose_export,
)


@dataclass
class FakeDockModel:
    id: str
    name: str
    pose: Any = None
    contacts: list[Any] = field(default_factory=list)
    hbonds: list[Any] = field(default_factory=list)
    hydrophobic: list[Any] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    files: dict[str, Any] = field(default_factory=dict)
    score: float = 0.0
    rank: int = 0
    status: str = "succeeded"


def build_reference_multipose() -> tuple[MultiPoseAnalysisResult, list[FakeDockModel]]:
    models = [
        FakeDockModel("2", "pose1.pdb_model_2", score=14.7661, rank=1),
        FakeDockModel("3", "pose2.pdb_model_3", score=8.3064, rank=3),
        FakeDockModel("4", "pose3.pdb_model_4", score=12.9108, rank=2),
    ]
    pose_results = [
        PoseAnalysisResult(
            pose_id=model.id,
            name=model.name,
            dock_model=model,
            pose=model,
            status=AnalysisStatus.SUCCEEDED,
        )
        for model in models
    ]
    aggregate = MultiPoseAnalysisResult(
        name="DockAnalyzer automatic ChimeraX analysis",
        pose_results=pose_results,
        status=AnalysisStatus.SUCCEEDED,
    )
    return aggregate, models


class Stage3MultiposeRepresentationTests(unittest.TestCase):
    def test_analyze_collector_unwraps_aggregate_to_real_models(self):
        aggregate, models = build_reference_multipose()
        collected = _export_collect_dock_models(aggregate)
        self.assertEqual(len(collected), 3)
        self.assertEqual(tuple(id(item) for item in collected), tuple(id(item) for item in models))
        self.assertNotIn(id(aggregate), {id(item) for item in collected})

    def test_export_target_contains_exactly_three_real_pose_sources(self):
        aggregate, models = build_reference_multipose()
        target = resolve_export_stage_target(multipose_result=aggregate)
        self.assertEqual(target.kind.value, "multipose")
        self.assertEqual(len(target.dock_models), 3)
        self.assertEqual(len(target.export_sources), 3)
        self.assertEqual(tuple(id(item) for item in target.export_sources), tuple(id(item) for item in models))

    def test_native_export_normalizer_expands_aggregate_and_deduplicates_models(self):
        aggregate, models = build_reference_multipose()
        context = prepare_multipose_export([aggregate, *models])
        self.assertEqual(len(context.poses), 3)
        self.assertEqual(len(context.records), 3)
        self.assertEqual([record.get("dock_model_id") for record in context.records], ["2", "3", "4"])

    def test_pose_result_wrappers_are_unwrapped_before_native_export(self):
        aggregate, models = build_reference_multipose()
        context = prepare_multipose_export(list(aggregate.pose_results))
        self.assertEqual(len(context.poses), 3)
        self.assertEqual(tuple(id(item) for item in context.poses), tuple(id(item) for item in models))

    def test_json_and_pose_csv_report_three_poses_not_four(self):
        aggregate, models = build_reference_multipose()
        with tempfile.TemporaryDirectory() as directory:
            output_dir = Path(directory)
            options = MultiposeExportOptions(
                export=ExportOptions(
                    output_dir=output_dir,
                    basename="stage3_test",
                    formats=("json", "csv"),
                    include_manifest=False,
                    include_provenance=False,
                    update_model_files=False,
                    hash_algorithm=None,
                )
            )
            result = export_multiple_poses(
                [aggregate, *models],
                options=options,
                basename="stage3_test",
            )
            self.assertFalse(result.errors, result.errors)
            payload = json.loads((output_dir / "stage3_test.json").read_text(encoding="utf-8"))
            self.assertEqual(payload["pose_count"], 3)
            self.assertEqual(len(payload["poses"]), 3)
            self.assertNotIn("DockAnalyzer automatic ChimeraX analysis", [item.get("name") for item in payload["poses"]])

            with (output_dir / "stage3_test_poses_poses.csv").open("r", encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(len(rows), 3)

    def test_ranking_table_row_count_tracks_real_pose_count(self):
        aggregate, models = build_reference_multipose()
        context = prepare_multipose_export(
            [aggregate, *models],
            options=MultiposeExportOptions(
                export=ExportOptions(
                    formats=("json", "csv"),
                    include_manifest=False,
                    include_provenance=False,
                    update_model_files=False,
                    hash_algorithm=None,
                )
            ),
        )
        ranking = context.tables.get("ranking")
        self.assertIsNotNone(ranking)
        self.assertEqual(len(ranking.rows), 3)


if __name__ == "__main__":
    unittest.main()
