# Stage 8 tests

Stage 8 targets the hydrophobic-analysis runtime bottleneck without changing
scientific criteria. The tests verify exact contact equivalence with the
pre-optimization path, one candidate-pair search per workflow, timing
instrumentation, cached local-geometry equivalence, local-connectivity
adjacency equivalence, batch-refinement equivalence, and a conservative
performance regression guard.
