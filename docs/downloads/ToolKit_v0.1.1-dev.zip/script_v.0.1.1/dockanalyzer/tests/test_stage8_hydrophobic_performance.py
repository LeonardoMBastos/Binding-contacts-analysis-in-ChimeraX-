"""Stage 8 regression tests for hydrophobic performance optimizations."""

from __future__ import annotations

import time
import unittest
from unittest import mock

import numpy as np

from dockanalyzer import hydrophobic as h


class Stage8HydrophobicPerformanceTests(unittest.TestCase):
    def _fixture(self, *, receptor_count: int = 180, ligand_count: int = 14):
        rng = np.random.default_rng(20260807)
        receptor_atoms = []
        receptor_descriptors = []
        for index, coordinate in enumerate(
            rng.uniform(-14.0, 14.0, size=(receptor_count, 3))
        ):
            atom = h.make_synthetic_atom(
                f"R{index}",
                "C",
                coordinate,
                index=index,
                aliphatic=True,
                partial_charge=0.0,
            )
            descriptor = h.HydrophobicAtom(
                atom=atom,
                role=h.HYDROPHOBIC_ROLE_RECEPTOR,
                atom_type=h.HYDROPHOBIC_ATOM_TYPE_ALIPHATIC,
                is_hydrophobic=True,
                is_aliphatic=True,
                element="C",
                atomic_number=6,
                atom_index=index,
                identifier=f"R{index}",
                partial_charge=np.float64(0.0),
            )
            receptor_atoms.append(atom)
            receptor_descriptors.append(descriptor)

        ligand_atoms = []
        ligand_descriptors = []
        for index, coordinate in enumerate(
            rng.uniform(-4.0, 4.0, size=(ligand_count, 3))
        ):
            atom = h.make_synthetic_atom(
                f"L{index}",
                "C",
                coordinate,
                index=index,
                aliphatic=True,
                partial_charge=0.0,
            )
            descriptor = h.HydrophobicAtom(
                atom=atom,
                role=h.HYDROPHOBIC_ROLE_LIGAND,
                atom_type=h.HYDROPHOBIC_ATOM_TYPE_ALIPHATIC,
                is_hydrophobic=True,
                is_aliphatic=True,
                element="C",
                atomic_number=6,
                atom_index=index,
                identifier=f"L{index}",
                partial_charge=np.float64(0.0),
            )
            ligand_atoms.append(atom)
            ligand_descriptors.append(descriptor)

        return h.HydrophobicAtomCollections(
            receptor_atoms=receptor_atoms,
            ligand_atoms=ligand_atoms,
            receptor_hydrophobic_atoms=receptor_descriptors,
            ligand_hydrophobic_atoms=ligand_descriptors,
        )

    def _legacy_reference(self, prepared):
        receptor_descriptors = tuple(prepared.receptor_hydrophobic_atoms)
        ligand_descriptors = tuple(prepared.ligand_hydrophobic_atoms)
        minimum_cutoff = h.get_default_minimum_hydrophobic_distance()
        maximum_cutoff = h.get_default_maximum_hydrophobic_distance()
        pairs = h.find_hydrophobic_pairs(
            prepared,
            minimum_distance=minimum_cutoff,
            maximum_distance=maximum_cutoff,
            remove_duplicates=True,
            validate_pairs=True,
        )
        interactions = []
        for receptor_descriptor, ligand_descriptor in pairs:
            geometry = h.analyze_hydrophobic_pair_geometry(
                receptor_descriptor,
                ligand_descriptor,
                receptor_candidates=receptor_descriptors,
                ligand_candidates=ligand_descriptors,
                maximum_contact_distance=maximum_cutoff,
            )
            interactions.append(
                h.create_hydrophobic_interaction(
                    receptor_descriptor,
                    ligand_descriptor,
                    geometry=geometry,
                    receptor_candidates=receptor_descriptors,
                    ligand_candidates=ligand_descriptors,
                    minimum_distance=minimum_cutoff,
                    maximum_distance=maximum_cutoff,
                    detection_method=h.HYDROPHOBIC_METHOD_ATOMIC,
                    include_geometry_metadata=True,
                )
            )
        interactions = h.deduplicate_hydrophobic_interactions(
            interactions,
            prefer_highest_score=True,
        )
        return tuple(
            sorted(
                interactions,
                key=lambda interaction: (
                    -float(interaction.score),
                    float(interaction.distance),
                    interaction.interaction_identifier or "",
                ),
            )
        )

    def _serialized(self, interactions):
        return [
            interaction.to_dict(
                include_atoms=False,
                include_residue=False,
                include_descriptors=False,
            )
            for interaction in interactions
        ]

    def test_optimized_contacts_match_legacy_reference_exactly(self):
        prepared = self._fixture()
        legacy = self._legacy_reference(prepared)
        optimized = h.detect_hydrophobic_contacts(
            prepared,
            prepared_collections=prepared,
        )
        self.assertEqual(self._serialized(optimized), self._serialized(legacy))

    def test_complete_detection_searches_candidate_pairs_once(self):
        prepared = self._fixture(receptor_count=80, ligand_count=8)
        original = h.find_hydrophobic_pairs
        with mock.patch.object(
            h,
            "find_hydrophobic_pairs",
            wraps=original,
        ) as patched:
            h.detect_hydrophobic_interactions(
                prepared,
                prepared_collections=prepared,
            )
        self.assertEqual(patched.call_count, 1)

    def test_intermediate_detection_searches_candidate_pairs_once(self):
        prepared = self._fixture(receptor_count=80, ligand_count=8)
        original = h.find_hydrophobic_pairs
        with mock.patch.object(
            h,
            "find_hydrophobic_pairs",
            wraps=original,
        ) as patched:
            h.run_hydrophobic_detection(
                prepared,
                prepared_collections=prepared,
            )
        self.assertEqual(patched.call_count, 1)

    def test_detection_metadata_contains_internal_timings(self):
        prepared = self._fixture(receptor_count=100, ligand_count=10)
        result = h.detect_hydrophobic_interactions(
            prepared,
            prepared_collections=prepared,
        )
        metadata = dict(result.metadata)
        timings = metadata.get("performance_timings_seconds")
        self.assertIsInstance(timings, dict)
        expected = {
            "preparation_seconds",
            "pair_search_seconds",
            "neighbor_cache_seconds",
            "interaction_creation_seconds",
            "interaction_finalization_seconds",
            "statistics_seconds",
            "pair_accounting_seconds",
            "total_seconds",
        }
        self.assertTrue(expected.issubset(timings))
        self.assertTrue(all(float(timings[key]) >= 0.0 for key in expected))
        self.assertEqual(
            metadata.get("performance_optimization"),
            "stage8_cached_local_geometry",
        )

    def test_cached_geometry_matches_public_geometry(self):
        prepared = self._fixture(receptor_count=90, ligand_count=9)
        pairs = h.find_hydrophobic_pairs(prepared)
        self.assertTrue(pairs)
        receptor_descriptor, ligand_descriptor = pairs[0]
        receptor_candidates = tuple(prepared.receptor_hydrophobic_atoms)
        ligand_candidates = tuple(prepared.ligand_hydrophobic_atoms)
        radius = h.DEFAULT_LOCAL_CONTACT_RADIUS
        receptor_cache = h._build_local_hydrophobic_neighbor_cache(
            (receptor_descriptor,),
            receptor_candidates,
            radius=radius,
        )
        ligand_cache = h._build_local_hydrophobic_neighbor_cache(
            (ligand_descriptor,),
            ligand_candidates,
            radius=radius,
        )
        cached = h._analyze_hydrophobic_pair_geometry_cached(
            receptor_descriptor,
            ligand_descriptor,
            receptor_neighbors=receptor_cache[id(receptor_descriptor.atom)],
            ligand_neighbors=ligand_cache[id(ligand_descriptor.atom)],
            local_radius=radius,
            maximum_contact_distance=h.get_default_maximum_hydrophobic_distance(),
        )
        public = h.analyze_hydrophobic_pair_geometry(
            receptor_descriptor,
            ligand_descriptor,
            receptor_candidates=receptor_candidates,
            ligand_candidates=ligand_candidates,
            local_radius=radius,
            maximum_contact_distance=h.get_default_maximum_hydrophobic_distance(),
        )
        self.assertEqual(
            cached.to_dict(include_atoms=False, include_descriptors=False),
            public.to_dict(include_atoms=False, include_descriptors=False),
        )

    def test_local_region_clustering_matches_legacy_connectivity(self):
        prepared = self._fixture(receptor_count=140, ligand_count=12)
        interactions = h.detect_hydrophobic_contacts(
            prepared,
            prepared_collections=prepared,
        )
        cutoff = h.DEFAULT_LOCAL_INTERACTION_CLUSTER_DISTANCE
        expected_adjacency = {index: set() for index in range(len(interactions))}
        for first_index in range(len(interactions)):
            for second_index in range(first_index + 1, len(interactions)):
                if h.are_hydrophobic_interactions_locally_connected(
                    interactions[first_index],
                    interactions[second_index],
                    grouping_distance=cutoff,
                    require_same_pose=True,
                ):
                    expected_adjacency[first_index].add(second_index)
                    expected_adjacency[second_index].add(first_index)
        optimized_adjacency = h._build_hydrophobic_local_adjacency(
            interactions,
            grouping_distance=cutoff,
            require_same_pose=True,
            require_same_chain=False,
        )
        self.assertEqual(optimized_adjacency, expected_adjacency)

    def test_batch_refinement_matches_legacy_per_interaction_path(self):
        prepared = self._fixture(receptor_count=140, ligand_count=12)
        interactions = h.detect_hydrophobic_contacts(
            prepared,
            prepared_collections=prepared,
        )
        regions = h.cluster_hydrophobic_local_regions(
            interactions,
            require_same_pose=True,
            identify_hotspots=False,
        )
        region_by_key = {}
        for region in regions:
            region_interactions = tuple(region.interactions)
            for interaction in region_interactions:
                region_by_key[h.hydrophobic_interaction_pair_key(interaction)] = (
                    region_interactions
                )
        legacy_refined = []
        for interaction in interactions:
            related = region_by_key.get(
                h.hydrophobic_interaction_pair_key(interaction),
                (interaction,),
            )
            legacy_refined.append(
                h.refine_hydrophobic_interaction(
                    interaction,
                    related_interactions=related,
                )
            )
        legacy_refined = h.deduplicate_hydrophobic_interactions(
            legacy_refined,
            prefer_highest_score=True,
        )
        legacy_refined = tuple(
            sorted(
                legacy_refined,
                key=lambda item: (
                    -float(item.score),
                    -float(item.strength),
                    float(item.distance),
                    item.interaction_identifier or "",
                ),
            )
        )
        optimized_refined = h.refine_hydrophobic_interactions(interactions)
        self.assertEqual(
            self._serialized(optimized_refined),
            self._serialized(legacy_refined),
        )

    def test_optimized_detection_is_materially_faster_than_legacy_path(self):
        prepared = self._fixture(receptor_count=220, ligand_count=16)
        start = time.perf_counter()
        legacy = self._legacy_reference(prepared)
        legacy_seconds = time.perf_counter() - start

        start = time.perf_counter()
        optimized = h.detect_hydrophobic_contacts(
            prepared,
            prepared_collections=prepared,
        )
        optimized_seconds = time.perf_counter() - start

        self.assertEqual(self._serialized(optimized), self._serialized(legacy))
        self.assertLess(optimized_seconds, legacy_seconds * 0.75)


if __name__ == "__main__":
    unittest.main()
