"""Stage 9 regression tests for receptor reuse and spatial neighbor search."""

from __future__ import annotations

from types import SimpleNamespace
import unittest
from unittest import mock

import numpy as np

from dockanalyzer import contacts as c
from dockanalyzer import geometry as g
from dockanalyzer import hbonds as hb
from dockanalyzer import hydrophobic as hy
from dockanalyzer import utils as u
from dockanalyzer import export as ex


class Stage9SpatialReceptorCacheTests(unittest.TestCase):
    def setUp(self):
        self.rng = np.random.default_rng(20260807)

    def test_cell_list_neighbors_match_bruteforce_exactly(self):
        receptor = self.rng.uniform(-20.0, 20.0, size=(700, 3))
        queries = self.rng.uniform(-6.0, 6.0, size=(24, 3))
        radius = 4.75
        index = g._build_spatial_neighbor_index(
            receptor,
            prefer_scipy=False,
            cell_size=4.0,
        )
        observed = index.query_ball_points(queries, radius)
        expected = []
        for point in queries:
            squared = np.sum((receptor - point) ** 2, axis=1)
            expected.append(tuple(np.where(squared <= radius * radius)[0].tolist()))
        self.assertEqual(observed, tuple(expected))
        self.assertEqual(index.backend, "cell_list")

    def test_auto_spatial_backend_matches_bruteforce(self):
        receptor = self.rng.normal(size=(350, 3)) * 9.0
        queries = self.rng.normal(size=(19, 3)) * 3.0
        radius = 5.2
        index = g._build_spatial_neighbor_index(receptor)
        observed = index.query_ball_points(queries, radius)
        expected = tuple(
            tuple(
                np.where(np.sum((receptor - point) ** 2, axis=1) <= radius * radius)[0].tolist()
            )
            for point in queries
        )
        self.assertEqual(observed, expected)
        self.assertIn(index.backend, {"cell_list", "scipy_ckdtree"})

    def _contact_fixture(self):
        receptor_residue = c._TestResidue("REC", 1)
        ligand_residue = c._TestResidue("LIG", 2)
        element = c._TestElement("C", 6)
        receptor = [
            c._TestAtom(f"R{i}", element, np.asarray(x), receptor_residue)
            for i, x in enumerate(self.rng.uniform(-12.0, 12.0, size=(320, 3)))
        ]
        ligand = [
            c._TestAtom(f"L{i}", element, np.asarray(x), ligand_residue)
            for i, x in enumerate(self.rng.uniform(-4.0, 4.0, size=(18, 3)))
        ]
        return ligand, receptor

    def test_contacts_spatial_search_matches_legacy_fallback_exactly(self):
        ligand, receptor = self._contact_fixture()
        optimized = c.find_atom_contacts(
            ligand,
            receptor,
            cutoff=4.5,
            sort_by_distance=False,
        )
        with mock.patch.object(
            c.geometry,
            "_build_spatial_neighbor_index",
            side_effect=RuntimeError("force legacy fallback"),
        ):
            legacy = c.find_atom_contacts(
                ligand,
                receptor,
                cutoff=4.5,
                sort_by_distance=False,
            )
        key = lambda item: (
            item.atom_1_index,
            item.atom_2_index,
            round(float(item.distance), 12),
            item.classification,
        )
        self.assertEqual([key(x) for x in optimized], [key(x) for x in legacy])

    def test_contacts_normal_path_does_not_build_pairwise_matrix(self):
        ligand, receptor = self._contact_fixture()
        with mock.patch.object(
            c,
            "_calculate_squared_distance_block",
            side_effect=AssertionError("matrix path should not execute"),
        ):
            result = c.find_atom_contacts(ligand, receptor, cutoff=4.5)
        self.assertIsInstance(result, tuple)

    def test_hbond_candidate_search_matches_legacy_fallback_exactly(self):
        donor_residue = hb.make_fake_residue("LIG", 1)
        acceptor_residue = hb.make_fake_residue("ASP", 2)
        donors = [
            hb.make_fake_atom(f"N{i}", "N", x, residue=donor_residue, index=i)
            for i, x in enumerate(self.rng.uniform(-5.0, 5.0, size=(32, 3)))
        ]
        acceptors = [
            hb.make_fake_atom(f"O{i}", "O", x, residue=acceptor_residue, index=i)
            for i, x in enumerate(self.rng.uniform(-9.0, 9.0, size=(240, 3)))
        ]
        optimized = hb.find_hbond_candidate_pairs(
            donors,
            acceptors,
            maximum_distance=3.5,
            distance_tolerance=0.1,
            allow_intramolecular=True,
        )
        with mock.patch.object(
            hb,
            "_build_spatial_neighbor_index",
            side_effect=RuntimeError("force legacy fallback"),
        ):
            legacy = hb.find_hbond_candidate_pairs(
                donors,
                acceptors,
                maximum_distance=3.5,
                distance_tolerance=0.1,
                allow_intramolecular=True,
            )
        key = lambda item: (item[0].name, item[1].name, round(float(item[2]), 12))
        self.assertEqual([key(x) for x in optimized], [key(x) for x in legacy])

    def _hydrophobic_descriptors(self, receptor_count=330, ligand_count=22):
        receptor = []
        ligand = []
        for i, coordinate in enumerate(
            self.rng.uniform(-14.0, 14.0, size=(receptor_count, 3))
        ):
            atom = hy.make_synthetic_atom(
                f"R{i}", "C", coordinate, index=i, aliphatic=True, partial_charge=0.0
            )
            receptor.append(
                hy.HydrophobicAtom(
                    atom=atom,
                    role=hy.HYDROPHOBIC_ROLE_RECEPTOR,
                    atom_type=hy.HYDROPHOBIC_ATOM_TYPE_ALIPHATIC,
                    is_hydrophobic=True,
                    is_aliphatic=True,
                    element="C",
                    atomic_number=6,
                    atom_index=i,
                    identifier=f"R{i}",
                    partial_charge=np.float64(0.0),
                )
            )
        for i, coordinate in enumerate(
            self.rng.uniform(-4.0, 4.0, size=(ligand_count, 3))
        ):
            atom = hy.make_synthetic_atom(
                f"L{i}", "C", coordinate, index=i, aliphatic=True, partial_charge=0.0
            )
            ligand.append(
                hy.HydrophobicAtom(
                    atom=atom,
                    role=hy.HYDROPHOBIC_ROLE_LIGAND,
                    atom_type=hy.HYDROPHOBIC_ATOM_TYPE_ALIPHATIC,
                    is_hydrophobic=True,
                    is_aliphatic=True,
                    element="C",
                    atomic_number=6,
                    atom_index=i,
                    identifier=f"L{i}",
                    partial_charge=np.float64(0.0),
                )
            )
        return receptor, ligand

    def test_hydrophobic_spatial_indices_match_legacy_matrix_exactly(self):
        receptor, ligand = self._hydrophobic_descriptors()
        optimized = hy.hydrophobic_contact_indices(receptor, ligand)
        with mock.patch.object(
            hy,
            "_build_spatial_neighbor_index",
            side_effect=RuntimeError("force legacy fallback"),
        ):
            legacy = hy.hydrophobic_contact_indices(receptor, ligand)
        self.assertEqual(optimized, legacy)

    def test_prepared_receptor_reuses_hydrophobic_atoms_and_descriptors(self):
        receptor_atoms = [
            hy.make_synthetic_atom(
                f"R{i}",
                "C",
                (float(i % 10), float((i // 10) % 8), 0.0),
                index=i,
                aliphatic=True,
                partial_charge=0.0,
            )
            for i in range(80)
        ]
        ligand_atoms = [
            hy.make_synthetic_atom(
                f"L{i}", "C", (float(i), 1.0, 2.8), index=i,
                aliphatic=True, partial_charge=0.0,
            )
            for i in range(5)
        ]
        receptor = SimpleNamespace(atoms=tuple(receptor_atoms))
        ligand = SimpleNamespace(atoms=tuple(ligand_atoms))
        prepared = u._prepare_receptor_cache(receptor, prefer_scipy=False)
        first = hy.prepare_hydrophobic_atom_collections(receptor, ligand)
        cache_size = len(prepared.derived)
        second = hy.prepare_hydrophobic_atom_collections(receptor, ligand)
        self.assertIs(first.receptor_atoms, second.receptor_atoms)
        self.assertIs(first.receptor_hydrophobic_atoms, second.receptor_hydrophobic_atoms)
        self.assertEqual(len(prepared.derived), cache_size)
        self.assertGreaterEqual(cache_size, 2)

    def test_prepared_receptor_private_cache_is_not_serialized(self):
        atoms = [
            hy.make_synthetic_atom(
                f"R{i}", "C", (float(i), 0.0, 0.0), index=i,
                aliphatic=True, partial_charge=0.0,
            )
            for i in range(10)
        ]
        receptor = SimpleNamespace(atoms=tuple(atoms))
        prepared = u._prepare_receptor_cache(receptor, prefer_scipy=False)
        model = u.DockModel(name="pose", receptor=receptor)
        u._attach_prepared_receptor_cache((model,), prepared)
        serialized = ex.to_serializable(model)
        serialized_text = repr(serialized)
        self.assertNotIn("_dockanalyzer_prepared_receptor", serialized_text)
        self.assertNotIn("_PreparedReceptor", serialized_text)

    def test_one_prepared_receptor_can_be_attached_to_multiple_dockmodels(self):
        atoms = [
            hy.make_synthetic_atom(
                f"R{i}", "C", (float(i), 0.0, 0.0), index=i,
                aliphatic=True, partial_charge=0.0,
            )
            for i in range(12)
        ]
        receptor = SimpleNamespace(atoms=tuple(atoms))
        prepared = u._prepare_receptor_cache(receptor, prefer_scipy=False)
        models = [u.DockModel(name="p1", receptor=receptor), u.DockModel(name="p2", receptor=receptor)]
        u._attach_prepared_receptor_cache(models, prepared)
        self.assertIs(u._prepared_receptor_from_dock_model(models[0], receptor=receptor), prepared)
        self.assertIs(u._prepared_receptor_from_dock_model(models[1], receptor=receptor), prepared)


if __name__ == "__main__":
    unittest.main()
