"""Stage 7 regression tests for ChimeraX visualization commands and diagnostics."""

from __future__ import annotations

import unittest
from types import SimpleNamespace

from dockanalyzer import analyze, visualization


class Stage7VisualizationRuntimeTests(unittest.TestCase):
    def _failed_native_outcome(self, *, optional: bool = False):
        failed_command = SimpleNamespace(
            status=SimpleNamespace(value="failed"),
            text="camera orthographic",
            error_type="UserError",
            error_message="Expected camera mode 'ortho'.",
            sequence=0,
            optional=optional,
        )
        execution = SimpleNamespace(
            state=SimpleNamespace(value="failed"),
            commands=(failed_command,),
            execution_mode=SimpleNamespace(value="immediate"),
        )
        plan = SimpleNamespace()
        state = SimpleNamespace(plan=plan, execution=execution)
        return SimpleNamespace(
            state=state,
            execution=execution,
            warnings=(),
            issues=(),
            model=None,
        )

    def _target(self):
        return analyze.VisualizationStageTarget(
            source=SimpleNamespace(name="stage7-source"),
            kind=analyze.VisualizationTargetKind.GENERIC,
            name="stage7-source",
        )

    def test_camera_renderer_uses_valid_ortho_token(self):
        action = SimpleNamespace(
            parameters={
                "component": "framing",
                "mode": visualization.CAMERA_MODE_ORTHOGRAPHIC,
                "fit": True,
                "selection": "#2 | #3 | #4",
            },
            selection=visualization.MolecularSelection("#2 | #3 | #4"),
        )
        commands = visualization._render_camera_action(action)
        self.assertEqual(commands[0], "camera ortho")
        self.assertNotIn("camera orthographic", commands)

    def test_compound_selection_is_one_chimerax_command_token(self):
        rendered = visualization.format_chimerax_selection("#2 | #3 | #4")
        self.assertEqual(rendered, "#2|#3|#4")
        action = SimpleNamespace(
            parameters={
                "component": "framing",
                "mode": visualization.CAMERA_MODE_ORTHOGRAPHIC,
                "fit": True,
                "selection": "#2 | #3 | #4",
            },
            selection=visualization.MolecularSelection("#2 | #3 | #4"),
        )
        commands = visualization._render_camera_action(action)
        self.assertIn("view #2|#3|#4 clip false", commands)

    def test_camera_renderer_never_emits_view_none(self):
        action = SimpleNamespace(
            parameters={
                "component": "framing",
                "mode": visualization.CAMERA_MODE_ORTHOGRAPHIC,
                "fit": True,
                "selection": "none",
            },
            selection=visualization.MolecularSelection.none(),
        )
        commands = visualization._render_camera_action(action)
        self.assertEqual(commands, ["camera ortho"])
        self.assertFalse(any(command.startswith("view none") for command in commands))

    def test_failed_native_command_makes_visualization_partial(self):
        output = analyze.adapt_native_visualization_result(
            self._failed_native_outcome(),
            target=self._target(),
            config=analyze.VisualizationIntegrationConfig(
                continue_on_error=True,
                execution_mode="immediate",
            ),
            visualization_module=visualization,
        )
        self.assertEqual(output.status, analyze.VisualizationIntegrationStatus.PARTIAL)
        self.assertEqual(output.metadata["failed_command_count"], 1)
        self.assertEqual(output.metadata["failed_execution_count"], 1)
        self.assertEqual(len(output.errors), 1)
        self.assertIn("ChimeraX command failed", output.errors[0])
        self.assertIn("camera orthographic", output.errors[0])

    def test_optional_failed_command_is_visible_as_warning(self):
        output = analyze.adapt_native_visualization_result(
            self._failed_native_outcome(optional=True),
            target=self._target(),
            config=analyze.VisualizationIntegrationConfig(
                continue_on_error=True,
                execution_mode="immediate",
            ),
            visualization_module=visualization,
        )
        self.assertEqual(output.status, analyze.VisualizationIntegrationStatus.SUCCEEDED)
        self.assertEqual(output.errors, ())
        self.assertEqual(len(output.warnings), 1)
        self.assertIn("ChimeraX command failed", output.warnings[0])

    def test_partial_stage_records_recoverable_error_diagnostic(self):
        output = analyze.adapt_native_visualization_result(
            self._failed_native_outcome(),
            target=self._target(),
            config=analyze.VisualizationIntegrationConfig(
                continue_on_error=True,
                execution_mode="immediate",
            ),
            visualization_module=visualization,
        )
        stage_result = analyze.visualization_stage_output_to_result(output)
        self.assertEqual(stage_result.status, analyze.StageStatus.PARTIAL)
        self.assertEqual(len(stage_result.errors), 1)
        issue = stage_result.errors[0]
        self.assertEqual(issue.code, "visualization_command_failed")
        self.assertTrue(issue.recoverable)
        compact = analyze._compact_stage_statuses({"visualization": stage_result})
        self.assertEqual(compact["visualization"]["status"], "partial")
        self.assertEqual(compact["visualization"]["error_count"], 1)

    def test_stage_command_failure_reaches_compact_run_diagnostics(self):
        output = analyze.adapt_native_visualization_result(
            self._failed_native_outcome(),
            target=self._target(),
            config=analyze.VisualizationIntegrationConfig(
                continue_on_error=True,
                execution_mode="immediate",
            ),
            visualization_module=visualization,
        )
        stage_result = analyze.visualization_stage_output_to_result(output)
        global_result = SimpleNamespace(
            diagnostics=None,
            stage_results={"visualization": stage_result},
        )
        result = SimpleNamespace(
            warnings=(),
            errors=(),
            analysis_output=SimpleNamespace(warnings=(), errors=()),
            post_actions=(),
        )
        warnings, errors = analyze._compact_run_diagnostics(result, (), global_result)
        self.assertEqual(warnings, [])
        self.assertEqual(len(errors), 1)
        self.assertEqual(errors[0]["stage"], analyze.STAGE_VISUALIZATION)
        self.assertEqual(errors[0]["code"], "visualization_command_failed")
        self.assertIn("ChimeraX command failed", errors[0]["message"])


if __name__ == "__main__":
    unittest.main()
