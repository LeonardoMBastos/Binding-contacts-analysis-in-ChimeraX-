"""Stage 1 scientific regression checks for the DockAnalyzer reference run.

This module is test-only infrastructure. It does not import or modify the
production analysis pipeline and never injects baseline values into runtime
analysis.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Sequence


TEST_DIRECTORY = Path(__file__).resolve().parent
DEFAULT_BASELINE_PATH = (
    TEST_DIRECTORY / "fixtures" / "reference_run_20260807_144231_baseline.json"
)


@dataclass(frozen=True)
class ValidationReport:
    """Result of a reference-run validation."""

    errors: tuple[str, ...] = field(default_factory=tuple)
    warnings: tuple[str, ...] = field(default_factory=tuple)

    @property
    def succeeded(self) -> bool:
        return not self.errors


def _load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise TypeError(f"Expected a JSON object in {path}")
    return data


def _as_pose_id(value: Any) -> str:
    return str(value)


def _score_map(summary: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    scores = summary.get("scores", [])
    if not isinstance(scores, Sequence) or isinstance(scores, (str, bytes)):
        return {}
    mapped: dict[str, Mapping[str, Any]] = {}
    for item in scores:
        if isinstance(item, Mapping) and item.get("pose_id") is not None:
            mapped[_as_pose_id(item["pose_id"])] = item
    return mapped


def _ranking_map(summary: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    ranking = summary.get("ranking", {})
    entries = ranking.get("entries", []) if isinstance(ranking, Mapping) else []
    mapped: dict[str, Mapping[str, Any]] = {}
    if isinstance(entries, Sequence) and not isinstance(entries, (str, bytes)):
        for item in entries:
            if isinstance(item, Mapping) and item.get("pose_id") is not None:
                mapped[_as_pose_id(item["pose_id"])] = item
    return mapped


def validate_generic_run_summary(summary: Mapping[str, Any]) -> ValidationReport:
    """Validate structural invariants that should hold for any multipose run."""

    errors: list[str] = []
    warnings: list[str] = []

    inputs = summary.get("inputs", {})
    input_poses = inputs.get("poses", []) if isinstance(inputs, Mapping) else []
    input_pose_ids = {
        _as_pose_id(item.get("identifier"))
        for item in input_poses
        if isinstance(item, Mapping) and item.get("identifier") is not None
    }

    scores = _score_map(summary)
    ranking = _ranking_map(summary)
    stages = summary.get("stages", {})
    pose_stages = stages.get("poses", {}) if isinstance(stages, Mapping) else {}
    stage_pose_ids = {
        _as_pose_id(key) for key in pose_stages.keys()
    } if isinstance(pose_stages, Mapping) else set()

    if not input_pose_ids:
        errors.append("No input poses were recorded in the run summary.")
    if input_pose_ids != set(scores):
        errors.append(
            f"Input pose IDs {sorted(input_pose_ids)} do not match score pose IDs "
            f"{sorted(scores)}."
        )
    if input_pose_ids != set(ranking):
        errors.append(
            f"Input pose IDs {sorted(input_pose_ids)} do not match ranking pose IDs "
            f"{sorted(ranking)}."
        )
    if input_pose_ids != stage_pose_ids:
        errors.append(
            f"Input pose IDs {sorted(input_pose_ids)} do not match per-pose stage IDs "
            f"{sorted(stage_pose_ids)}."
        )

    ranking_block = summary.get("ranking", {})
    if isinstance(ranking_block, Mapping):
        entries = ranking_block.get("entries", [])
        if isinstance(entries, Sequence) and entries:
            ordered = sorted(
                (item for item in entries if isinstance(item, Mapping)),
                key=lambda item: int(item.get("rank", 10**9)),
            )
            first_id = _as_pose_id(ordered[0].get("pose_id")) if ordered else None
            best_id = ranking_block.get("best_pose_id")
            if best_id is not None and first_id != _as_pose_id(best_id):
                errors.append(
                    f"best_pose_id={best_id!r} does not match rank-1 pose {first_id!r}."
                )

        validity = ranking_block.get("validity", {})
        if isinstance(validity, Mapping):
            comparable_count = sum(
                1 for item in scores.values() if bool(item.get("score_comparable"))
            )
            recorded = validity.get("comparable_result_count")
            if recorded is not None and int(recorded) != comparable_count:
                errors.append(
                    "Ranking comparable_result_count does not match score records."
                )

    if summary.get("status") == "succeeded" and summary.get("errors"):
        warnings.append("Run status is succeeded but the summary contains errors.")

    return ValidationReport(tuple(errors), tuple(warnings))


def validate_scientific_baseline(
    summary: Mapping[str, Any],
    baseline: Mapping[str, Any],
) -> ValidationReport:
    """Compare one run summary with the frozen scientific reference values."""

    errors: list[str] = []
    warnings: list[str] = []
    generic = validate_generic_run_summary(summary)
    errors.extend(generic.errors)
    warnings.extend(generic.warnings)

    expected_results = baseline.get("scientific_results", {})
    scores = _score_map(summary)
    ranking = _ranking_map(summary)
    tolerance = float(baseline.get("score_absolute_tolerance", 1e-6))

    if not isinstance(expected_results, Mapping):
        errors.append("Baseline scientific_results is not a mapping.")
        return ValidationReport(tuple(errors), tuple(warnings))

    if set(scores) != set(expected_results):
        errors.append(
            f"Reference pose IDs {sorted(expected_results)} do not match run pose IDs "
            f"{sorted(scores)}."
        )

    for pose_id, expected in expected_results.items():
        if not isinstance(expected, Mapping):
            errors.append(f"Invalid baseline record for pose {pose_id}.")
            continue
        actual = scores.get(_as_pose_id(pose_id))
        rank_actual = ranking.get(_as_pose_id(pose_id))
        if actual is None:
            continue

        if int(actual.get("interaction_count", -1)) != int(expected["interaction_count"]):
            errors.append(
                f"Pose {pose_id}: interaction_count changed from "
                f"{expected['interaction_count']} to {actual.get('interaction_count')}."
            )

        actual_score = actual.get("score")
        expected_score = expected.get("score")
        if actual_score is None or expected_score is None or not math.isclose(
            float(actual_score),
            float(expected_score),
            rel_tol=1e-9,
            abs_tol=tolerance,
        ):
            errors.append(
                f"Pose {pose_id}: score changed from {expected_score} to {actual_score}."
            )

        for key in ("status", "score_comparable", "failed_stages"):
            if actual.get(key) != expected.get(key):
                errors.append(
                    f"Pose {pose_id}: {key} changed from {expected.get(key)!r} "
                    f"to {actual.get(key)!r}."
                )

        if rank_actual is None or int(rank_actual.get("rank", -1)) != int(expected["rank"]):
            errors.append(
                f"Pose {pose_id}: rank changed from {expected['rank']} to "
                f"{None if rank_actual is None else rank_actual.get('rank')}."
            )

    ranking_block = summary.get("ranking", {})
    expected_ranking = baseline.get("ranking", {})
    if isinstance(ranking_block, Mapping) and isinstance(expected_ranking, Mapping):
        best_actual = _as_pose_id(ranking_block.get("best_pose_id"))
        best_expected = _as_pose_id(expected_ranking.get("best_pose_id"))
        if best_actual != best_expected:
            errors.append(
                f"Best pose changed from {best_expected!r} to {best_actual!r}."
            )

        entries = ranking_block.get("entries", [])
        ordered_actual = [
            _as_pose_id(item.get("pose_id"))
            for item in sorted(
                (item for item in entries if isinstance(item, Mapping)),
                key=lambda item: int(item.get("rank", 10**9)),
            )
        ] if isinstance(entries, Sequence) else []
        ordered_expected = [
            _as_pose_id(item) for item in expected_ranking.get("ordered_pose_ids", [])
        ]
        if ordered_actual != ordered_expected:
            errors.append(
                f"Ranking order changed from {ordered_expected} to {ordered_actual}."
            )

    return ValidationReport(tuple(errors), tuple(warnings))


def validate_paths(run_summary_path: Path, baseline_path: Path) -> ValidationReport:
    return validate_scientific_baseline(
        _load_json(run_summary_path),
        _load_json(baseline_path),
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Validate a DockAnalyzer run summary against the Stage 1 scientific baseline."
    )
    parser.add_argument("run_summary", type=Path, help="Path to a run_summary JSON file.")
    parser.add_argument(
        "--baseline",
        type=Path,
        default=DEFAULT_BASELINE_PATH,
        help="Optional path to a scientific baseline JSON file.",
    )
    args = parser.parse_args()

    report = validate_paths(args.run_summary, args.baseline)
    for warning in report.warnings:
        print(f"WARNING: {warning}")
    for error in report.errors:
        print(f"ERROR: {error}")
    if report.succeeded:
        print("PASS: scientific baseline and generic multipose invariants are preserved.")
        return 0
    print(f"FAIL: {len(report.errors)} regression(s) detected.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
