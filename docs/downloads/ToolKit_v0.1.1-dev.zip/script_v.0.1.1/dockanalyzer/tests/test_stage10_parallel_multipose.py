"""Stage 10 regression tests for safe detached multipose parallelism."""

from __future__ import annotations

import threading
import time
import unittest
from unittest import mock

from dockanalyzer import analyze as a
from dockanalyzer import utils as u


def _fixture():
    receptor = u._SelfTestAtomicStructure(
        "receptor", "1", ["ALA", "VAL", "PHE"], atoms_per_residue=4
    )
    poses = [
        u._SelfTestAtomicStructure(
            f"pose{i + 1}", str(i + 2), ["LIG"], atoms_per_residue=4
        )
        for i in range(3)
    ]
    return receptor, poses


def _config(mode: str, workers: int) -> a.AnalysisConfig:
    return a.AnalysisConfig(
        runtime=a.AnalysisRuntimeConfig(
            analysis_mode=a.ANALYSIS_MODE_MULTIPOSE,
            failure_policy=a.FAILURE_POLICY_PERMISSIVE,
            execution_mode=mode,
            max_workers=workers,
            attach_results=True,
            collect_timings=True,
        ),
        requested_stages=(
            a.STAGE_CONTACTS,
            a.STAGE_HBONDS,
            a.STAGE_HYDROPHOBIC,
            a.STAGE_PI,
            a.STAGE_SALTBRIDGE,
            a.STAGE_CONSOLIDATION,
            a.STAGE_SCORING,
            a.STAGE_VALIDATION,
            a.STAGE_FINALIZATION,
        ),
        enable_scoring=True,
        enable_consensus=False,
    )


def _run(mode: str, workers: int, **kwargs):
    receptor, poses = _fixture()
    output = a.run_multipose_analysis(
        receptor=receptor,
        poses=poses,
        config=_config(mode, workers),
        options={
            "build_consensus": False,
            "run_native_multipose_scoring": False,
        },
        **kwargs,
    )
    return output


class Stage10ParallelMultiposeTests(unittest.TestCase):
    def test_detached_structure_contains_no_source_atom_references(self):
        receptor, _ = _fixture()
        detached, atom_map, residue_map = a._detach_atomic_structure_for_workers(receptor)
        self.assertEqual(len(detached.atoms), len(receptor.atoms))
        self.assertTrue(all(id(atom) not in {id(x) for x in receptor.atoms} for atom in detached.atoms))
        self.assertTrue(all(id(value) != key for key, value in atom_map.items()))
        self.assertTrue(all(id(value) != key for key, value in residue_map.items()))
        self.assertTrue(all(atom.structure is detached for atom in detached.atoms))

    def test_parallel_and_sequential_scientific_results_match(self):
        sequential = _run(a.EXECUTION_MODE_SEQUENTIAL, 1)
        parallel = _run(a.EXECUTION_MODE_AUTOMATIC, 3)
        seq = [
            (
                result.status.value,
                result.interaction_count,
                a._multipose_pose_numeric_score(result),
                result.failed_stages,
            )
            for result in sequential.pose_results
        ]
        par = [
            (
                result.status.value,
                result.interaction_count,
                a._multipose_pose_numeric_score(result),
                result.failed_stages,
            )
            for result in parallel.pose_results
        ]
        self.assertEqual(par, seq)
        self.assertTrue(parallel.context.metadata["multipose_parallel"]["enabled"])
        self.assertEqual(parallel.context.metadata["multipose_parallel"]["worker_count"], 3)

    def test_parallel_results_are_synchronized_to_original_dockmodels(self):
        output = _run(a.EXECUTION_MODE_AUTOMATIC, 3)
        originals = output.preparation.dock_models
        self.assertEqual(len(originals), 3)
        for original, result in zip(originals, output.pose_results):
            self.assertIs(result.dock_model, original)
            self.assertEqual(len(original.contacts), len(result.interactions.contacts))
            self.assertTrue(result.metadata.get("parallel_worker_detached"))

    def test_completion_order_does_not_change_pose_order(self):
        original_runner = a.run_single_pose_analysis

        def delayed_runner(*args, **kwargs):
            model = kwargs.get("dock_model")
            name = getattr(model, "name", "")
            if "pose1" in name:
                time.sleep(0.08)
            elif "pose2" in name:
                time.sleep(0.04)
            return original_runner(*args, **kwargs)

        with mock.patch.object(a, "run_single_pose_analysis", side_effect=delayed_runner):
            output = _run(a.EXECUTION_MODE_AUTOMATIC, 3)
        self.assertEqual(
            [item.name for item in output.pose_results],
            ["pose1_model_2", "pose2_model_3", "pose3_model_4"],
        )

    def test_stage_callbacks_are_replayed_on_orchestration_thread(self):
        callback_threads = []

        def callback(_stage, _result):
            callback_threads.append(threading.current_thread().name)

        output = _run(
            a.EXECUTION_MODE_AUTOMATIC,
            3,
            stage_callback=callback,
        )
        self.assertTrue(output.succeeded)
        self.assertTrue(callback_threads)
        self.assertEqual(set(callback_threads), {threading.current_thread().name})

    def test_detachment_failure_falls_back_to_sequential(self):
        with mock.patch.object(
            a,
            "_detach_dock_models_for_workers",
            side_effect=a.AnalysisConcurrencyError("synthetic detach failure"),
        ):
            output = _run(a.EXECUTION_MODE_AUTOMATIC, 3)
        self.assertTrue(output.succeeded)
        info = output.context.metadata.get("multipose_parallel", {})
        self.assertFalse(info.get("enabled"))
        self.assertEqual(info.get("fallback"), "sequential")
        self.assertEqual(len(output.pose_results), 3)

    def test_chimerax_autorun_requests_safe_automatic_parallelism(self):
        config = a._build_chimerax_autorun_config(
            a.Path("/tmp/dockanalyzer-stage10"),
            file_prefix="stage10",
        )
        self.assertEqual(config.runtime.execution_mode, a.EXECUTION_MODE_AUTOMATIC)
        self.assertGreaterEqual(config.runtime.max_workers, 1)
        self.assertFalse(config.runtime.allow_chimerax_threads)


if __name__ == "__main__":
    unittest.main()
