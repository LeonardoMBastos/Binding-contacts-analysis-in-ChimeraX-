"""Stage 4 regression tests for multipose report normalization."""

from __future__ import annotations

import unittest

from dockanalyzer import report
from dockanalyzer.analyze import (
    AnalysisStatus,
    MultiPoseAnalysisResult,
    PoseAnalysisResult,
    ReportIntegrationConfig,
    build_report_document as build_integrated_report_document,
    resolve_report_stage_target,
)
from tests.test_stage3_multipose_representation import FakeDockModel


def _interaction(residue: str, distance: float, score: float = 1.0) -> dict[str, object]:
    return {
        "ligand_atom": "C1",
        "receptor_atom": "CA",
        "receptor_residue": residue,
        "chain_id": "A",
        "distance": distance,
        "score": score,
        "strength": "moderate",
    }


def build_report_fixture() -> tuple[MultiPoseAnalysisResult, list[FakeDockModel]]:
    models = [
        FakeDockModel("2", "pose1.pdb_model_2", score=14.7661, rank=1),
        FakeDockModel("3", "pose2.pdb_model_3", score=8.3064, rank=3),
        FakeDockModel("4", "pose3.pdb_model_4", score=12.9108, rank=2),
    ]
    models[0].contacts = [
        _interaction("TYR10", 3.1),
        _interaction("PHE11", 3.4),
    ]
    models[0].hbonds = [_interaction("SER12", 2.8)]
    models[1].contacts = [_interaction("LEU20", 3.6)]
    models[1].hydrophobic = [_interaction("VAL21", 3.9)]
    models[2].contacts = [_interaction("ILE30", 3.5)]

    pose_results = [
        PoseAnalysisResult(
            pose_id=model.id,
            name=model.name,
            dock_model=model,
            pose=model,
            status=AnalysisStatus.SUCCEEDED,
        )
        for model in models
    ]
    aggregate = MultiPoseAnalysisResult(
        name="DockAnalyzer automatic ChimeraX analysis",
        pose_results=pose_results,
        status=AnalysisStatus.SUCCEEDED,
    )
    return aggregate, models


def _key_value_content(document: report.ReportDocument, section_id: report.ReportSectionID) -> dict[str, object]:
    section = document.get_section(section_id)
    if section is None:
        return {}
    for block in section.blocks:
        if block.kind is report.ReportBlockKind.KEY_VALUE:
            return dict(block.content)
    return {}


class Stage4MultiposeReportTests(unittest.TestCase):
    def test_direct_multipose_report_unwraps_aggregate(self):
        aggregate, _ = build_report_fixture()
        document = report.create_multipose_report(aggregate)
        summary = _key_value_content(document, report.ReportSectionID.INTERACTIONS)
        self.assertEqual(summary.get("Total interactions"), 6)

    def test_pose_collection_aggregates_interaction_containers(self):
        _, models = build_report_fixture()
        section = report.summarize_interactions(models)
        self.assertEqual(section.total_interactions, 6)
        counts = {item.family.value: item.count for item in section.families}
        self.assertEqual(counts.get("contact"), 4)
        self.assertEqual(counts.get("hydrogen_bond"), 1)
        self.assertEqual(counts.get("hydrophobic"), 1)
        self.assertNotIn("unknown", counts)

    def test_overview_uses_aggregate_real_interaction_count(self):
        _, models = build_report_fixture()
        document = report.create_multipose_report(models)
        overview = _key_value_content(document, report.ReportSectionID.OVERVIEW)
        self.assertEqual(overview.get("Total interactions"), 6)
        self.assertEqual(overview.get("Pose name"), "3 poses")

    def test_multipose_section_contains_three_real_poses(self):
        aggregate, _ = build_report_fixture()
        document = report.create_multipose_report(aggregate)
        summary = _key_value_content(document, report.ReportSectionID.MULTIPOSE)
        self.assertEqual(summary.get("Total poses"), 3)

    def test_analyze_integration_passes_real_dock_models_to_report(self):
        aggregate, models = build_report_fixture()
        target = resolve_report_stage_target(multipose_result=aggregate)
        self.assertEqual(len(target.dock_models), 3)
        document = build_integrated_report_document(
            target,
            ReportIntegrationConfig(
                build_document=True,
                render_content=False,
                write_files=False,
                attach_result=False,
                validate_document=False,
            ),
            report_module=report,
        )
        summary = _key_value_content(document, report.ReportSectionID.INTERACTIONS)
        self.assertEqual(summary.get("Total interactions"), 6)
        self.assertEqual(tuple(id(item) for item in target.dock_models), tuple(id(item) for item in models))

    def test_markdown_contains_real_families_not_unknown_placeholder(self):
        aggregate, _ = build_report_fixture()
        document = report.create_multipose_report(aggregate)
        markdown = report.render_report_markdown(document)
        self.assertIn("**Total interactions:** 6", markdown)
        self.assertIn("contact", markdown)
        self.assertIn("hydrogen", markdown.lower())
        self.assertIn("hydrophobic", markdown.lower())
        self.assertNotIn("| unknown | Unknown interactions |", markdown)


if __name__ == "__main__":
    unittest.main()
