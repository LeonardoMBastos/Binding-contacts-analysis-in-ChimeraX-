"""Stage 2 regression tests for bounded DockAnalyzer export serialization."""

from __future__ import annotations

import json
import tempfile
import unittest
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from dockanalyzer.analyze import DockModelStageCacheEntry
from dockanalyzer.export import (
    ExportOptions,
    MultiposeExportOptions,
    dock_model_to_record,
    export_multiple_poses,
    to_serializable,
)


LARGE_SENTINEL = "CACHE_PAYLOAD_MUST_NOT_BE_EXPORTED"
HBOND_SENTINEL = "HBOND_RUNTIME_PAYLOAD_MUST_NOT_BE_EXPORTED"


@dataclass
class FakeHydrogenBondResults:
    results: dict[str, Any]
    pose_order: list[str]
    failed_poses: dict[str, str] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class FakeDockModel:
    id: str
    name: str
    contacts: list[Any] = field(default_factory=list)
    hbonds: list[Any] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    files: dict[str, Any] = field(default_factory=dict)
    score: float = 1.0
    rank: int = 1
    status: str = "succeeded"


def make_pose() -> FakeDockModel:
    cache_entry = DockModelStageCacheEntry(
        cache_key="cache-1",
        stage="hydrophobic",
        value={"blob": LARGE_SENTINEL * 100_000},
        result_status="succeeded",
    )
    cache = {
        "schema": "dockanalyzer.dock_model_cache",
        "version": "1.0",
        "entries": {"cache-1": cache_entry},
        "hits": 2,
        "misses": 1,
        "stale": 0,
        "evictions": 0,
        "updated_at": "2026-08-07T00:00:00+00:00",
    }
    hbond_results = FakeHydrogenBondResults(
        results={
            "pose1": {
                "receptor_atoms": [HBOND_SENTINEL * 10_000],
                "ligand_atoms": ["C1", "N1"],
            }
        },
        pose_order=["pose1"],
    )
    return FakeDockModel(
        id="2",
        name="pose1.pdb_model_2",
        metadata={
            "analysis_cache": cache,
            "hydrogen_bond_results": hbond_results,
            "analysis_status": "succeeded",
            "timings": {"hydrophobic": 1.25},
        },
    )


class Stage2ExportSafetyTests(unittest.TestCase):
    def test_cache_entry_direct_serialization_never_contains_value(self):
        pose = make_pose()
        entry = pose.metadata["analysis_cache"]["entries"]["cache-1"]
        serialized = to_serializable(entry)
        text = json.dumps(serialized)
        self.assertNotIn(LARGE_SENTINEL, text)
        self.assertNotIn('"value"', text)
        self.assertIn("value_type", serialized)

    def test_analysis_cache_is_exported_as_bounded_summary(self):
        record = dock_model_to_record(make_pose())
        cache = record["metadata"]["analysis_cache"]
        self.assertEqual(cache["serialization"], "summary_only")
        self.assertEqual(cache["entry_count"], 1)
        self.assertNotIn("value", cache["entries"]["cache-1"])
        text = json.dumps(record)
        self.assertNotIn(LARGE_SENTINEL, text)

    def test_hydrogen_bond_runtime_container_is_summarized(self):
        record = dock_model_to_record(make_pose())
        summary = record["metadata"]["hydrogen_bond_results"]
        self.assertEqual(summary["serialization"], "summary_only")
        self.assertEqual(summary["result_count"], 1)
        self.assertEqual(summary["pose_order"], ["pose1"])
        text = json.dumps(record)
        self.assertNotIn(HBOND_SENTINEL, text)

    def test_public_metadata_is_preserved(self):
        record = dock_model_to_record(make_pose())
        metadata = record["metadata"]
        self.assertEqual(metadata["analysis_status"], "succeeded")
        self.assertEqual(metadata["timings"]["hydrophobic"], 1.25)

    def test_record_size_is_independent_of_cached_payload_size(self):
        record = dock_model_to_record(make_pose())
        payload = json.dumps(record, ensure_ascii=False)
        self.assertLess(len(payload), 50_000)

    def test_multipose_json_and_csv_remain_bounded(self):
        with tempfile.TemporaryDirectory() as directory:
            output_dir = Path(directory)
            options = MultiposeExportOptions(
                export=ExportOptions(
                    output_dir=output_dir,
                    basename="stage2_test",
                    formats=("json", "csv"),
                    include_metadata=True,
                    include_manifest=False,
                    include_provenance=False,
                    update_model_files=False,
                    hash_algorithm=None,
                )
            )
            result = export_multiple_poses(
                [make_pose(), make_pose(), make_pose()],
                options=options,
                basename="stage2_test",
            )
            self.assertFalse(result.errors, result.errors)
            json_path = output_dir / "stage2_test.json"
            poses_csv = output_dir / "stage2_test_poses_poses.csv"
            self.assertTrue(json_path.exists())
            self.assertTrue(poses_csv.exists())
            self.assertLess(json_path.stat().st_size, 100_000)
            self.assertLess(poses_csv.stat().st_size, 100_000)
            text = json_path.read_text(encoding="utf-8")
            self.assertNotIn(LARGE_SENTINEL, text)
            self.assertNotIn(HBOND_SENTINEL, text)


if __name__ == "__main__":
    unittest.main()
