# Stage 3 — Multipose representation regression tests

Stage 3 prevents aggregate analysis containers from being exported as synthetic poses.

The tests verify that:

- `MultiPoseAnalysisResult` is unwrapped to its real DockModels for export;
- `PoseAnalysisResult` wrappers are unwrapped before native multipose export;
- aggregate + explicit pose inputs are deduplicated;
- JSON `pose_count`, pose CSV rows, and ranking rows match the real pose count;
- the aggregate result name never appears as an exported pose.

These tests are cumulative with Stages 1 and 2 and do not change scientific detection or scoring logic.
