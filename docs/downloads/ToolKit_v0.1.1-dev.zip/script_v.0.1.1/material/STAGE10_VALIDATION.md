# DockAnalyzer — Stage 10 Validation

## Scope

Stage 10 adds safe multipose parallel execution while preserving the Stage 9
scientific behavior and all Stage 1–9 output, diagnostic and performance fixes.

## Production changes

Only `dockanalyzer/analyze.py` was changed in Stage 10.

### Safe detached workers

Before concurrent execution, receptor and pose molecular objects are read on the
orchestration thread and converted to private plain-Python/NumPy snapshots. The
snapshots preserve the analysis-facing atom, residue, coordinate, element,
charge, topology, bond and atom-spec information used by the interaction
modules. Worker threads therefore do not receive the original ChimeraX atomic
objects.

Results are synchronized back to the original DockModels on the orchestration
thread. Stage/progress callbacks are also replayed on that thread.

### Execution policy

The ChimeraX autorun profile now requests:

- `execution_mode = automatic`
- `max_workers = min(8, os.cpu_count())`, with a minimum of 1
- `allow_chimerax_threads = False`

For multipose runs, automatic/threaded execution uses at most one worker per
pose. Explicit sequential mode remains sequential.

If molecular detachment cannot safely represent an input, the optimization
falls back to the validated sequential path before worker results are attached.

### Timing semantics

Parallel pose durations overlap. The run summary now distinguishes:

- `pose_runtime_seconds`: sum of individual pose durations
- `pose_wall_runtime_seconds`: real elapsed time for the parallel pose block
- `parallel_overlap_seconds`: overlapped pose time
- `parallel_execution`: worker count, detachment time and parallel wall time

The Stage 5 accounted/unattributed runtime calculation uses wall time during
parallel execution, preventing double-counting.

## Scientific-equivalence validation

A deterministic full interaction pipeline was run in both sequential and
parallel modes. For every pose, the following were identical:

- analysis status
- interaction count
- integrated score
- failed stages
- input pose order

The test exercises contacts, hydrogen bonds, hydrophobic interactions, pi
interactions, salt bridges, consolidation, scoring, validation and finalization.

## Stage 10 regression tests

`tests/test_stage10_parallel_multipose.py` verifies:

1. detached structures do not retain source atom/residue identities;
2. sequential and parallel scientific results match;
3. results are synchronized to the original DockModels;
4. completion order cannot reorder poses;
5. stage callbacks are replayed on the orchestration thread;
6. detachment failure falls back to sequential execution;
7. ChimeraX autorun requests safe automatic parallelism without enabling raw
   ChimeraX worker threads.

## Validation results

- cumulative Stage 1–10 tests: **67/67 PASS**
- Stage 10 tests: **7/7 PASS**
- `analyze.py` quick self-tests: **42/42 PASS**
- `export.py` self-tests: **60/60 PASS**
- `report.py` self-tests: **80/80 PASS**
- `visualization.py` self-tests: **98/98 PASS**
- `hydrophobic.py` self-tests: **192/192 PASS**
- `hbonds.py` quick self-tests: **151/151 PASS**
- `geometry.py` self-tests: **10/10 PASS**
- `contacts.py` self-tests: **PASS**
- `compileall`: **PASS**
- normal import: **PASS**
- `python -O` import: **PASS**
- `python -OO` import: **PASS**
- public `analyze.py` API names: **2207 -> 2207**
- public callable signature changes: **0**

## Environmental limitation

A real UCSF ChimeraX session is not available in this validation environment.
Therefore the safety adapter and parallel orchestration were validated with
ChimeraX-like molecular fixtures, but the real-world speedup must be measured
with the next ChimeraX run. The run summary now contains the fields needed to
measure that speedup directly.
