# DockAnalyzer Stage 2 Validation

## Scope

Stage 2 addresses export-size and export-performance failures without changing scientific detection, scoring, ranking, or pose-analysis algorithms.

Production changes are limited to `dockanalyzer/export.py`.

## Changes

1. `analysis_cache` is exported as bounded diagnostic metadata.
   - Cached `DockModelStageCacheEntry.value` payloads are never serialized by the standard export path.
   - Cache counters, stage identifiers, fingerprints, status, timestamps, hit counts, and `value_type` remain available.
2. Direct serialization of `DockModelStageCacheEntry` uses a safe summary instead of generic dataclass expansion.
3. Duplicated `hydrogen_bond_result` / `hydrogen_bond_results` containers stored inside DockModel metadata are summarized rather than re-exporting full receptor/ligand atom collections.
4. Public metadata such as analysis status and timings remains serialized normally.
5. Scientific interactions and scoring records are not replaced by these summaries; the change applies to duplicated runtime/cache metadata.

## Regression validation

- Stage 1 scientific baseline tests: PASS.
- Stage 2 export-safety tests: 6/6 PASS.
- Combined external tests: 12/12 PASS.
- `export.py` internal self-tests: 60/60 PASS.
- `py_compile` for the modified module: PASS.
- Normal import: PASS.
- `python -O` import: PASS.
- `python -OO` import: PASS.
- `export.py` public `__all__`: unchanged from Stage 1.
- Production files changed from Stage 1: `export.py` only.

## Performance / size diagnostics

Synthetic regression benchmark with 10 MB cached payload plus 10 MB duplicated hydrogen-bond runtime payload:

- Stage 1 serialized record: 20,000,462 characters.
- Stage 2 serialized record: 570 characters.
- Stage 1 `json.dumps`: ~0.225 s in this environment.
- Stage 2 `json.dumps`: ~0.000049 s in this environment.

This benchmark is intentionally synthetic and is used to prove that standard export size is no longer proportional to cached stage-result payload size.

Projection from the problematic 2026-08-07 pose CSV:

- Original flattened columns: 12,884.
- Columns originating from `metadata.analysis_cache`: 11,842.
- Columns originating from `metadata.hydrogen_bond_results`: 736.
- Remaining columns after excluding those duplicated runtime payload trees: 306.
- Original CSV size: 12,664,023 bytes.
- Projected CSV size for the retained pre-existing columns: 286,864 bytes.

The actual Stage 2 export will also add small summary fields for the excluded runtime containers, so the final size will not be identical to this projection.

## Environment limitation

A complete ChimeraX production rerun cannot be performed in this environment. Therefore, the exact size and elapsed time of the real three-pose run must be confirmed in ChimeraX. The regression tests specifically reproduce the serialization mechanism that caused the oversized output and verify that cached payload contents cannot enter the standard JSON/CSV export path.

## Stage 2 acceptance criteria

PASS in the local validation environment:

- No cached stage `value` is emitted by standard export.
- Export size does not scale with synthetic cache payload size.
- Heavy hydrogen-bond runtime containers in metadata are summarized.
- Public metadata is preserved.
- Stage 1 scientific reference values remain unchanged.
- Export public API remains unchanged.
