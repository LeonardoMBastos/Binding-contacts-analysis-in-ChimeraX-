# DockAnalyzer Stage 7 validation

## Scope

Stage 7 corrects ChimeraX visualization command rendering and visualization-stage diagnostics. It does not modify molecular interaction detection, cutoffs, scoring rules, ranking semantics, export safety rules, or report aggregation.

Production files changed relative to Stage 6:

- `dockanalyzer/visualization.py`
- `dockanalyzer/analyze.py`

## Problems corrected

### Invalid orthographic camera command

The visualization renderer previously emitted:

```text
camera orthographic
```

ChimeraX expects the orthographic camera token `ortho`. Stage 7 now emits:

```text
camera ortho
```

Perspective mode remains `camera mono`.

### Invalid compound object specifications in commands

Compound molecular selections were internally represented with readable whitespace, for example:

```text
#2 | #3 | #4
```

When inserted directly into a ChimeraX command, command-level whitespace separates arguments. Stage 7 keeps the internal readable representation but renders Boolean object specifications as a single command token:

```text
#2|#3|#4
```

This applies through `format_chimerax_selection()` and therefore protects camera framing and other command renderers that consume compound molecular selections.

### Invalid `view none` command

The previous camera renderer could emit:

```text
view none clip false
```

when no framing selection was resolved. Stage 7 routes camera selections through `format_chimerax_selection(..., allow_none=True)` and omits the `view` command entirely when the selection is empty/none.

### Failed ChimeraX commands were not reflected in stage status

Native `CommandExecutionResult` objects already recorded command failures, but the analyze integration adapter only inspected validation issues and outcome warnings. As a result, an execution containing failed commands could still be reported as visualization `succeeded`.

Stage 7 now inspects native execution commands. A failed non-optional command:

1. is preserved as a bounded diagnostic message;
2. increments `failed_command_count` and `failed_execution_count`;
3. makes a usable visualization result `partial` rather than `succeeded`;
4. becomes a recoverable `visualization_command_failed` stage error;
5. reaches compact run diagnostics and therefore the ChimeraX `run_summary`.

Failed optional commands remain visible as warnings without converting otherwise usable output into a failed stage.

### Error severity was misclassified in compact diagnostics

`IssueSeverity` is an `IntEnum`. The compact diagnostic collector previously converted its numeric value to text (for example `40`) and then compared it with textual tokens such as `error`, causing some real error issues to be misclassified as warnings.

Stage 7 now handles numeric severities directly and retains textual fallback handling.

## Regression validation

- Stage 1-7 cumulative regression tests: **43/43 passed**.
- Stage 7 regression tests: **7/7 passed**.
- `visualization.py` complete self-tests: **98/98 passed**.
- `analyze.py` fast final self-tests: **42/42 passed**.
- `export.py` complete self-tests: **60/60 passed**.
- `compileall`: passed.
- normal imports of all 13 DockAnalyzer modules: passed.
- imports under `python -O`: passed.
- imports under `python -OO`: passed.
- `analyze.py` public API (`__all__`): unchanged relative to Stage 6.
- `visualization.py` public API (`__all__`): unchanged relative to Stage 6.
- Only `dockanalyzer/analyze.py` and `dockanalyzer/visualization.py` changed among production modules relative to Stage 6.

## Scientific regression boundary

Stage 1 baseline tests continue to pass. Stage 7 does not modify `contacts.py`, `hbonds.py`, `hydrophobic.py`, `pi.py`, `saltbridge.py`, `scoring.py`, scientific cutoffs, interaction classification, or ranking calculations.

## Environmental limitation

The actual UCSF ChimeraX runtime is not available in this validation environment. The next real ChimeraX run should confirm that:

- no `camera orthographic` command is emitted;
- no `view none clip false` command is emitted;
- compound pose selections are sent as one atom-spec token;
- any remaining failed ChimeraX command is visible in the run summary as a visualization diagnostic instead of silent success.
