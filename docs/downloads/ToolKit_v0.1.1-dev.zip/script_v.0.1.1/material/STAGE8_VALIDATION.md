# Stage 8 Validation — Hydrophobic Performance

## Scope

Stage 8 optimizes the hydrophobic-analysis runtime bottleneck while preserving
all scientific cutoffs, interaction criteria, scoring rules, public names, and
public call signatures.

Only `dockanalyzer/hydrophobic.py` was modified among production modules.

## Performance changes

1. Candidate hydrophobic receptor-ligand pairs are searched once per detection
   workflow instead of being recomputed during contact creation.
2. Local receptor and ligand neighborhoods are cached for the atoms that occur
   in candidate pairs.
3. Pair-local contact geometry reuses one local distance matrix for contact
   count, compaction, density, and approximate contact area instead of
   reconstructing equivalent matrices repeatedly.
4. Local-region clustering caches interaction midpoints, pose identifiers,
   chain identifiers, and atom identities before pairwise connectivity checks.
5. Batch interaction refinement reuses one direct-connectivity adjacency map
   instead of reclustering and rediscovering each interaction's local
   neighborhood separately.
6. Hydrophobic detection metadata now includes small internal performance
   timings under `performance_timings_seconds`.

No KD-tree, SciPy dependency, multipose parallelism, receptor-wide shared cache,
or altered distance cutoff was introduced in this stage. Those architectural
optimizations remain reserved for later stages.

## Semantic equivalence checks

A deterministic Stage 7 vs Stage 8 comparison was run on synthetic receptor and
ligand systems.

- Contact-level serialized interactions: **0 differences**.
- Complete hydrophobic-analysis result, including final classifications,
  scores, residue groups, and statistics: **0 differences** after excluding
  the new Stage 8 timing-only metadata.
- Candidate/interactions ordering was preserved.
- `hydrophobic.py.__all__`: unchanged (**504 public names**).
- Public inspectable signatures: **0 changes**.

## Benchmarks

Deterministic synthetic benchmark, 700 receptor hydrophobic atoms and 28 ligand
hydrophobic atoms, 257 detected contacts:

- Stage 7 `detect_hydrophobic_contacts`: **7.6609 s**
- Stage 8 `detect_hydrophobic_contacts`: **0.2741 s**
- Observed speedup: **27.95x**
- Contact count before/after: **257 / 257**

Deterministic complete hydrophobic workflow benchmark:

- Stage 7: **3.1402 s**
- Stage 8: **1.2090 s**
- Observed speedup: **2.60x**
- Final interaction count: unchanged
- Final total hydrophobic score: unchanged

These synthetic timings are regression evidence, not a prediction of exact
ChimeraX runtime. The next real ChimeraX run should be used to quantify the
speedup for the user's receptor and ligand.

## Validation results

- Cumulative Stage 1–8 regression tests: **51/51 PASS**
- Stage 8-specific regression tests: **8/8 PASS**
- `hydrophobic.py` internal self-tests: **192/192 PASS**
- `analyze.py` fast self-tests: **42/42 PASS**
- `export.py` self-tests: **60/60 PASS**
- `report.py` self-tests: **80/80 PASS**
- `visualization.py` self-tests: **98/98 PASS**
- `compileall`: **PASS**
- Normal package imports: **PASS**
- Imports under `python -O`: **PASS**
- Imports under `python -OO`: **PASS**
- Stage 7 vs Stage 8 public API comparison: **PASS**

## Environmental limitation

ChimeraX is not available in this validation environment. Therefore the
software-level and synthetic molecular regressions pass, but the exact runtime
reduction for the real ChimeraX run must be measured in ChimeraX.
