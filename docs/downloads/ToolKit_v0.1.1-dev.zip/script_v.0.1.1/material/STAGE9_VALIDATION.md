# DockAnalyzer Stage 9 Validation

## Scope

Stage 9 introduces a private, reusable receptor-preparation layer and spatial neighbor search while preserving the existing scientific criteria and public API.

Production files changed relative to Stage 8:

- `dockanalyzer/analyze.py`
- `dockanalyzer/utils.py`
- `dockanalyzer/geometry.py`
- `dockanalyzer/contacts.py`
- `dockanalyzer/hbonds.py`
- `dockanalyzer/hydrophobic.py`

No scientific cutoff, interaction classification, scoring weight, ranking rule, or output schema was intentionally changed.

## Architecture changes

### Shared prepared receptor

`utils.py` now provides a private `_PreparedReceptor` runtime cache containing:

- receptor atom tuple;
- receptor scene coordinates;
- a reusable spatial index;
- detector-specific derived receptor values;
- thread-safe derived-value storage for future multipose parallelism.

`analyze.py` prepares this receptor once during model preparation and attaches the same private cache to the DockModels created for the poses.

The optimization is fail-safe: if preparation fails, the original non-cached detector paths remain available and the analysis is not aborted solely because the optimization failed.

### Spatial neighbor search

`geometry.py` now has a private spatial neighbor index with two backends:

1. `scipy.spatial.cKDTree`, loaded lazily when SciPy is available;
2. an internal cell-list implementation when SciPy is unavailable.

SciPy is therefore optional and no new required dependency was introduced.

The neighbor search is used to avoid full receptor-by-ligand distance matrices in the matrix-heavy atomic searches of:

- contacts;
- hydrogen-bond candidate generation;
- hydrophobic pair generation.

Every spatial candidate is still checked using the exact Euclidean-distance limits used by the previous implementation.

The legacy matrix implementations remain as automatic fallbacks if spatial-index construction or querying fails.

### Conservative treatment of pi and salt bridges

A generic atom-level binding-site truncation was not forced onto `pi.py` or `saltbridge.py`. These modules operate on complete aromatic/charged chemical groups, and prematurely removing atoms could break group recognition. They retain their existing chemically aware candidate filtering. This also avoids changing scientific semantics for stages that were not a measurable bottleneck in the reference run.

## Exact-equivalence regression tests

Stage 9 adds `tests/test_stage9_spatial_receptor_cache.py` with 9 tests.

The tests verify that:

1. the pure-Python cell-list backend exactly matches brute-force radius search;
2. the automatically selected backend exactly matches brute force;
3. contact pairs, ordering, distances and classifications exactly match the forced legacy matrix fallback;
4. normal contact search does not execute the pairwise-matrix path;
5. H-bond candidate pairs and distances exactly match the forced legacy fallback;
6. hydrophobic pair indices exactly match the forced legacy matrix fallback;
7. receptor hydrophobic atoms and descriptors are reused between poses/calls;
8. the prepared receptor private cache is not serialized by `export.py`;
9. one prepared receptor instance is shared by multiple DockModels.

## Cumulative validation

- Stage 1-9 regression tests: **60/60 PASS**
- `geometry.py` self-tests: **10/10 PASS**
- `contacts.py` self-tests: **PASS**
- `hbonds.py` quick self-tests: **151/151 PASS**
- `hydrophobic.py` self-tests: **192/192 PASS**
- `analyze.py` fast self-tests: **42/42 PASS**
- `export.py` self-tests: **60/60 PASS**
- `report.py` self-tests: **80/80 PASS**
- `visualization.py` self-tests: **98/98 PASS**
- `compileall`: **PASS**
- normal package import: **PASS**
- package import under `python -O`: **PASS**
- package import under `python -OO`: **PASS**

ChimeraX itself is not available in the validation environment, so ChimeraX-specific runtime behavior remains an environmental validation item for the next real run.

## Public API validation

The Stage 8 and Stage 9 public interfaces were compared for all modified modules.

| Module | Stage 8 public names | Stage 9 public names | Signature changes |
| --- | ---: | ---: | ---: |
| `analyze.py` | 2207 | 2207 | 0 |
| `contacts.py` | 97 | 97 | 0 |
| `geometry.py` | 81 | 81 | 0 |
| `hbonds.py` | 482 | 482 | 0 |
| `hydrophobic.py` | 504 | 504 | 0 |
| `utils.py` | 68 | 68 | 0 semantic changes |

The apparent textual difference detected in `utils.safe_execution` was only the process-specific memory address of an existing sentinel object used as a default value; its signature and behavior are unchanged.

## Performance observations

### Receptor preparation reuse

Synthetic receptor: 1,200 receptor atoms and 30 ligand atoms.

| Version | First preparation | Second preparation | Receptor descriptors reused |
| --- | ---: | ---: | --- |
| Stage 8 | 0.309 s | 0.315 s | No |
| Stage 9 | 0.315 s | **0.0084 s** | Yes |

The repeated receptor-side preparation is approximately **37x faster** in this fixture after the first preparation.

### Spatial H-bond candidate search

Synthetic fixture: 180 donor coordinates against 8,000 acceptor coordinates.

| Version | Median time | Candidate pairs |
| --- | ---: | ---: |
| Stage 8 | 0.0194 s | 469 |
| Stage 9 | **0.0032 s** | 469 |

This fixture produced approximately a **6x speedup** with identical candidates.

### Spatial backends

For 180 radius queries against 8,000 receptor coordinates, both backends returned the same 415 neighbors:

- SciPy `cKDTree`: ~0.00033 s median query time;
- internal cell list: ~0.00595 s median query time.

The cell-list backend is intentionally retained so the optimization remains available in ChimeraX installations without SciPy.

These are synthetic microbenchmarks, not promises for the real molecular run. The real gain must be measured from the next ChimeraX execution using the timing instrumentation introduced in Stages 5 and 8.

## Scientific-regression policy

Stage 9 changes how impossible atom pairs are excluded computationally, not the distance cutoffs or chemical rules used to accept interactions. Exact legacy fallbacks remain available and the new tests force comparison against them.

The Stage 1 scientific baseline remains part of the cumulative test suite.
