# DockAnalyzer — Stage 3 validation

## Scope

Stage 3 corrects multipose output representation without changing molecular interaction detection, scoring rules, or scientific cutoffs.

### Production files changed

- `dockanalyzer/analyze.py`
- `dockanalyzer/export.py`

No detector (`contacts.py`, `hbonds.py`, `hydrophobic.py`, `pi.py`, `saltbridge.py`) or scoring algorithm was changed.

## Changes

### `analyze.py`

`_export_collect_dock_models()` now unwraps analysis-result containers before applying broad DockModel duck typing:

- `PoseAnalysisResult` -> its concrete `dock_model`/pose;
- `MultiPoseAnalysisResult` -> DockModels belonging to its `pose_results`;
- batch/run wrappers -> their contained concrete analysis objects.

This prevents an aggregate `MultiPoseAnalysisResult` from becoming a synthetic extra pose during export.

### `export.py`

Multipose export now normalizes incoming items before generating records:

- aggregate multipose results are expanded into their pose results;
- single-pose result wrappers are unwrapped to concrete pose/DockModel objects;
- objects already encountered by identity are deduplicated.

This is a second defensive barrier for direct callers of `export_multiple_poses()`.

## Regression target

The reference run contains exactly three real poses (`#2`, `#3`, `#4`). Stage 3 is designed so an aggregate result plus those poses still produces exactly three exported pose records, never four.

Scientific baseline from Stage 1 remains unchanged:

- pose `#2`: 141 interactions, score 14.7661, rank 1;
- pose `#3`: 107 interactions, score 8.3064, rank 3;
- pose `#4`: 162 interactions, score 12.9108, rank 2.

## Validation results

- Stage 1/2/3 regression tests: **18/18 passed**.
- Stage 3 tests: **6/6 passed**.
- `export.py` internal self-tests: **60/60 passed**.
- `analyze.py` final fast self-test runner without environmental tests: **42/42 passed**.
- `compileall`: **passed**.
- Normal import: **passed**.
- `python -O` import: **passed**.
- `python -OO` import: **passed**.
- `analyze.py` public API: unchanged (**2207** exported names before/after).
- `export.py` public API: unchanged (**473** exported names before/after).
- Production-file diff from Stage 2: only `analyze.py` and `export.py` changed.

## Stage 3 specific acceptance tests

The test suite verifies that:

1. aggregate `MultiPoseAnalysisResult` resolves to exactly three concrete DockModels;
2. the export-stage target contains exactly three native pose sources;
3. aggregate + explicit pose objects are deduplicated;
4. `PoseAnalysisResult` wrappers are unwrapped;
5. JSON `pose_count` is 3 and pose CSV has 3 rows;
6. ranking table has 3 rows;
7. the aggregate name `DockAnalyzer automatic ChimeraX analysis` never becomes an exported pose.

## Environmental limitation

ChimeraX itself is not available in this validation environment. ChimeraX-specific runtime behavior therefore remains to be confirmed in a real ChimeraX run. This is an environmental limitation, not a Python compilation or regression-test failure.
