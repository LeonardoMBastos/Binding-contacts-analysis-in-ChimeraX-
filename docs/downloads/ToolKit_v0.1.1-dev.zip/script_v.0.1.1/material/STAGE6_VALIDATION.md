# DockAnalyzer Stage 6 validation

## Scope

Stage 6 corrects diagnostics and provenance collection. It does not change molecular interaction detection, cutoffs, scoring rules, ranking semantics, export safety rules, or scientific result structures.

Production files changed relative to Stage 5:

- `dockanalyzer/analyze.py`

## Problems corrected

### False internal-module unavailability

`collect_observability_module_versions()` previously called:

```python
load_analysis_module(name, validate=False)
```

`load_analysis_module()` does not accept a `validate` argument. The resulting `TypeError` was caught and converted into `available: false`, making importable modules such as `contacts`, `hbonds`, `hydrophobic`, `pi`, `saltbridge`, `scoring`, `export`, `report`, and `visualization` appear unavailable in provenance.

Stage 6 now uses the supported module-loading interface:

1. reuse an already loaded internal module when available;
2. otherwise call `load_analysis_module(name, required=False)`;
3. preserve the real module identity, file path, and version when available.

### `config` name shadowing

The function parameter named `config` previously shadowed the imported `dockanalyzer.config` module. Therefore the `config` provenance entry could be reported as unavailable even when the module was loaded correctly.

Stage 6 resolves `dockanalyzer.config` through the internal module loader instead of reading the function argument as a module.

### Silent diagnostic load failures

Unexpected internal-module load exceptions are no longer reduced to an unexplained `available: false` entry.

The full provenance entry now records a bounded diagnostic structure:

```json
{
  "available": false,
  "version": null,
  "load_error": {
    "type": "RuntimeError",
    "message": "..."
  }
}
```

The compact module-version structure used by the ChimeraX run summary also preserves this `load_error`, so a genuine future module-loading failure remains diagnosable from the run summary itself.

## Regression validation

- Stage 1-6 cumulative regression tests: **36/36 passed**.
- Stage 6 tests: **6/6 passed**.
- `analyze.py` fast final self-tests: **42/42 passed**.
- `export.py` self-tests: **60/60 passed**.
- observability convention validation: **passed**.
- internal module provenance availability: **13/13 available** in this validation environment.
- `compileall`: passed.
- normal package imports: passed.
- imports under `python -O`: passed.
- imports under `python -OO`: passed.
- `analyze.py` public API (`__all__`) is unchanged relative to Stage 5.
- Only `dockanalyzer/analyze.py` changed among production modules relative to Stage 5.

## Scientific regression boundary

Stage 1 baseline tests continue to pass. Stage 6 does not modify `contacts.py`, `hbonds.py`, `hydrophobic.py`, `pi.py`, `saltbridge.py`, `scoring.py`, or any scientific cutoff or scoring calculation.

## Environmental limitation

The real UCSF ChimeraX application runtime is not available in this validation environment. A subsequent ChimeraX run should therefore confirm that the generated run summary now reports the internal modules as available and, if a real loading problem occurs, includes the corresponding `load_error` diagnostic.
