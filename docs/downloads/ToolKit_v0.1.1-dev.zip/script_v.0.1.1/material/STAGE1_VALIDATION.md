# DockAnalyzer Stage 1 Validation

## Scope

Stage 1 creates a scientific regression safety net before any output or
performance correction. No production DockAnalyzer source file was modified.

## Frozen scientific reference

Reference run: `dockanalyzer_20260807_144231`

- Pose 2: 141 interactions; score 14.766099999999975; rank 1.
- Pose 3: 107 interactions; score 8.306399999999993; rank 3.
- Pose 4: 162 interactions; score 12.910799999999973; rank 2.
- All poses: `status=succeeded`, `score_comparable=true`, `failed_stages=[]`.
- Best pose: 2; ranking order: 2, 4, 3.

These values exist only under `tests/` and are never imported by production
analysis code.

## Generic invariants added

The validator checks that, for any multipose run summary:

- input pose IDs match score pose IDs;
- input pose IDs match ranking pose IDs;
- input pose IDs match per-pose stage IDs;
- `best_pose_id` matches the rank-1 entry;
- ranking comparable-result counts agree with score records.

These checks do not assume that future analyses contain three poses or have the
same scores as the reference run.

## Validation performed

- Production and test Python files: `py_compile` passed.
- Package import: passed under normal Python, `-O`, and `-OO`.
- `dockanalyzer.analyze` import: passed under normal Python, `-O`, and `-OO`.
- Stage 1 unit tests: 6/6 passed.
- Reference-run validator: passed.
- Production source comparison against the original ToolKit: no production
  source changes detected.

## Environmental boundary

No ChimeraX molecular execution was attempted in this environment. Stage 1
only establishes regression controls around the already successful reference
run and validates Python/package integrity.
