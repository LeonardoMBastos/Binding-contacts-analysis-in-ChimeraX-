# DockAnalyzer Stage 5 validation

## Scope

Stage 5 corrects export/runtime timing instrumentation. It does not change molecular interaction detection, cutoffs, scoring rules, ranking semantics, or scientific result structures.

Production files changed relative to Stage 4:

- `dockanalyzer/export.py`
- `dockanalyzer/analyze.py`

## Changes

### `export.py`

Multipose export now records bounded phase timings in `ExportResult.metadata["export_timings"]`:

- `resolve_options_seconds`
- `normalize_poses_seconds`
- `rank_poses_seconds`
- `resolve_output_seconds`
- `build_pose_records_seconds`
- `build_tables_seconds`
- `prepare_total_seconds`
- `build_payload_seconds`
- `serialize_json_seconds`
- `write_json_seconds`
- per-format write timings such as `write_csv_seconds`
- `collect_provenance_seconds`
- `calculate_hashes_seconds`
- `build_manifest_seconds`
- `write_manifest_seconds`
- `individual_pose_exports_seconds` when applicable
- `update_model_files_seconds` when applicable
- `total_seconds`

The `ExportResult.started_at` timestamp is now captured before multipose preparation, so `duration_seconds` includes preparation that was previously omitted.

JSON serialization and JSON disk writing are measured separately. Manifest hashing is also measured separately from manifest construction and writing.

### `analyze.py`

The export integration records `integration_timings` for configuration resolution, target resolution, reuse lookup, pre-validation, native export, post-validation, adaptation, attachment, and total integration time.

The pipeline-level export duration now covers the complete export integration path instead of reusing only the native writer duration.

Native `export_timings` are propagated through `ExportStageOutput` and the compact stage summary, so they can appear in the ChimeraX run summary.

`analyze_chimerax_session()` now captures its run-level `started_at` before dispatching the analysis. This fixes the prior inconsistency where `started_at` could be nearly equal to `finished_at` despite a long duration.

The compact run summary now also reports:

- pose runtime total;
- global-stage runtime total;
- accounted runtime;
- unattributed runtime;
- unattributed runtime percentage.

These values allow future runs to expose timing gaps directly.

## Regression validation

- Stage 1-5 cumulative tests: **30/30 passed**.
- Stage 5 tests: **6/6 passed**.
- `export.py` internal self-tests: **60/60 passed**.
- `analyze.py` fast final self-tests: **42/42 passed**, with no failures or environmental limitations selected.
- `compileall`: passed.
- normal import: passed.
- import under `python -O`: passed.
- import under `python -OO`: passed.
- `analyze.py` and `export.py` public API integrity self-tests: passed.
- Only `analyze.py` and `export.py` changed among production modules relative to Stage 4.

## Synthetic export check

Using three Stage 2 bounded-cache synthetic poses with JSON + CSV + manifest enabled:

- JSON: 5,311 bytes
- poses CSV: 2,384 bytes
- ranking CSV: 114 bytes
- manifest: 6,526 bytes
- total export duration in this environment: approximately 0.006 seconds

This synthetic timing is not a ChimeraX performance benchmark. It only verifies that the timing instrumentation is functioning and that the Stage 2 bounded serialization remains intact.

## Environmental limitation

UCSF ChimeraX is not available as the real application runtime in this validation environment. Native ChimeraX execution timing must therefore be confirmed in a subsequent real run. Code failures and ChimeraX environmental limitations remain distinct.
